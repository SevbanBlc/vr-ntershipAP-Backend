import { Question } from './types';

export const questions: Question[] = [
  {
    question: "Bir ekip projesinde, en çok hangi rolde bulunmayı tercih edersin?",
    answers: [
      {
        text: "Farklı görüşleri dinleyip ortak bir karara varmaya çalışan arabulucu",
        score: {
          communication: 5,
          analysis: 2,
          teamwork: 4,
          creativity: 3,
          technical: 1
        }
      },
      {
        text: "Projenin detaylarını planlayan ve süreçleri yöneten organizatör",
        score: {
          communication: 3,
          analysis: 4,
          teamwork: 3,
          creativity: 2,
          technical: 3
        }
      },
      {
        text: "Problemleri çözmeye odaklanan ve teknik detayları inceleyen analist",
        score: {
          communication: 2,
          analysis: 5,
          teamwork: 2,
          creativity: 3,
          technical: 4
        }
      },
      {
        text: "Yeni ve yaratıcı fikirler üreten vizyoner",
        score: {
          communication: 3,
          analysis: 2,
          teamwork: 2,
          creativity: 5,
          technical: 2
        }
      }
    ]
  },
  {
    question: "Bir teknoloji projesinde çalışırken karşılaştığın zorlukları nasıl aşarsın?",
    answers: [
      {
        text: "İnternetten araştırma yaparım ve farklı çözümleri denerim",
        score: {
          communication: 2,
          analysis: 4,
          teamwork: 2,
          creativity: 3,
          technical: 4
        }
      },
      {
        text: "Ekip arkadaşlarımla tartışır ve ortak bir çözüm bulmaya çalışırım",
        score: {
          communication: 5,
          analysis: 3,
          teamwork: 4,
          creativity: 3,
          technical: 2
        }
      },
      {
        text: "Sorunu daha küçük parçalara bölerek adım adım çözmeye çalışırım",
        score: {
          communication: 2,
          analysis: 5,
          teamwork: 2,
          creativity: 2,
          technical: 4
        }
      },
      {
        text: "Alışılmadık ve yaratıcı çözümler bulmaya çalışırım",
        score: {
          communication: 2,
          analysis: 3,
          teamwork: 2,
          creativity: 5,
          technical: 3
        }
      }
    ]
  },
  {
    question: "Hangi tip projelerde çalışmaktan daha çok keyif alırsın?",
    answers: [
      {
        text: "Kullanıcı deneyimini iyileştirmeye yönelik projeler",
        score: {
          communication: 4,
          analysis: 3,
          teamwork: 3,
          creativity: 4,
          technical: 3
        }
      },
      {
        text: "Verileri analiz ederek anlamlı sonuçlar çıkarma projeleri",
        score: {
          communication: 2,
          analysis: 5,
          teamwork: 2,
          creativity: 2,
          technical: 4
        }
      },
      {
        text: "Sistemlerin performansını ve güvenliğini iyileştiren teknik projeler",
        score: {
          communication: 2,
          analysis: 4,
          teamwork: 2,
          creativity: 2,
          technical: 5
        }
      },
      {
        text: "Yenilikçi ve deneysel teknolojileri keşfetme projeleri",
        score: {
          communication: 3,
          analysis: 3,
          teamwork: 2,
          creativity: 5,
          technical: 4
        }
      }
    ]
  },
  {
    question: "İş hayatında hangi yaklaşımı benimsersin?",
    answers: [
      {
        text: "Planlı ve sistematik çalışmayı tercih ederim",
        score: {
          communication: 3,
          analysis: 4,
          teamwork: 3,
          creativity: 2,
          technical: 3
        }
      },
      {
        text: "Esnek ve adaptif olmayı tercih ederim",
        score: {
          communication: 4,
          analysis: 3,
          teamwork: 3,
          creativity: 4,
          technical: 2
        }
      },
      {
        text: "Detaylara önem veririm ve titiz çalışırım",
        score: {
          communication: 2,
          analysis: 5,
          teamwork: 2,
          creativity: 2,
          technical: 4
        }
      },
      {
        text: "Yenilikçi ve risk almaya açık bir yaklaşım benimserim",
        score: {
          communication: 3,
          analysis: 2,
          teamwork: 2,
          creativity: 5,
          technical: 3
        }
      }
    ]
  },
  {
    question: "Boş zamanlarında en çok ne yapmaktan hoşlanırsın?",
    answers: [
      {
        text: "Arkadaşlarımla vakit geçirmek veya sosyal etkinliklere katılmak",
        score: {
          communication: 5,
          analysis: 2,
          teamwork: 4,
          creativity: 3,
          technical: 1
        }
      },
      {
        text: "Kitap okumak veya belgesel izlemek",
        score: {
          communication: 2,
          analysis: 4,
          teamwork: 2,
          creativity: 3,
          technical: 3
        }
      },
      {
        text: "Bilgisayar oyunları oynamak veya teknolojik projeler geliştirmek",
        score: {
          communication: 2,
          analysis: 3,
          teamwork: 2,
          creativity: 3,
          technical: 5
        }
      },
      {
        text: "Sanatsal aktiviteler (müzik, resim, yazı yazmak vb.)",
        score: {
          communication: 3,
          analysis: 2,
          teamwork: 2,
          creativity: 5,
          technical: 2
        }
      }
    ]
  }
];