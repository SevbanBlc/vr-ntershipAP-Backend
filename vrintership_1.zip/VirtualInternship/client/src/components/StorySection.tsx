import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface StoryChoice {
  text: string;
  consequence?: string;
  score?: {
    analysis?: number;
    communication?: number;
  };
  nextDimension?: string;
}

interface StoryPart {
  title: string;
  description: string;
  image?: string;
  dimension?: string;
  choices?: StoryChoice[];
}

interface StorySectionProps {
  storyPart: StoryPart;
  onChoice: (choice: StoryChoice) => void;
}

export const StorySection: React.FC<StorySectionProps> = ({ storyPart, onChoice }) => {
  const [selectedChoice, setSelectedChoice] = useState<number | null>(null);
  const [showConsequence, setShowConsequence] = useState(false);
  const [consequence, setConsequence] = useState<string | null>(null);
  const [selectedChoiceData, setSelectedChoiceData] = useState<StoryChoice | null>(null);
  const [readyToContinue, setReadyToContinue] = useState(false);

  const handleChoiceClick = (choice: StoryChoice, index: number) => {
    if (selectedChoice !== null) return; // Prevent multiple selections
    
    setSelectedChoice(index);
    setSelectedChoiceData(choice);
    
    if (choice.consequence) {
      setConsequence(choice.consequence);
      setShowConsequence(true);
      
      setTimeout(() => {
        setReadyToContinue(true);
      }, 1200);
    } else {
      setTimeout(() => {
        setReadyToContinue(true);
      }, 500);
    }
  };

  const handleContinue = () => {
    if (selectedChoiceData) {
      setShowConsequence(false);
      
      setTimeout(() => {
        onChoice(selectedChoiceData);
      }, 300);
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { delayChildren: 0.3, staggerChildren: 0.1 }
    },
    exit: { 
      opacity: 0,
      scale: 0.98,
      transition: { duration: 0.3 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { 
        type: "spring", 
        damping: 15, 
        stiffness: 200 
      }
    }
  };

  const choiceVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { 
        type: "spring", 
        damping: 15 
      }
    },
    selected: { 
      scale: 1.03,
      backgroundColor: "rgba(147, 51, 234, 0.1)",
      borderColor: "rgba(147, 51, 234, 0.5)",
      boxShadow: "0 4px 14px rgba(147, 51, 234, 0.15)",
      transition: { duration: 0.3 }
    },
    tap: { scale: 0.98 }
  };

  const consequenceVariants = {
    hidden: { opacity: 0, y: 20, scale: 0.95 },
    visible: { 
      opacity: 1, 
      y: 0, 
      scale: 1,
      transition: { 
        type: "spring", 
        damping: 20,
        stiffness: 300
      }
    },
    exit: { 
      opacity: 0, 
      y: -20, 
      scale: 0.95,
      transition: { duration: 0.2 }
    }
  };

  const buttonVariants = {
    hidden: { opacity: 0, scale: 0.8, y: 10 },
    visible: { 
      opacity: 1, 
      scale: 1,
      y: 0,
      transition: {
        type: "spring",
        damping: 12,
        stiffness: 200,
        delay: 0.2
      }
    },
    hover: { 
      scale: 1.05,
      boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)",
      transition: { 
        type: "spring", 
        damping: 10, 
        stiffness: 200 
      }
    },
    tap: { scale: 0.97 }
  };

  // Fallback image if none provided
  const imageUrl = storyPart.image || 'https://images.unsplash.com/photo-1585776245991-cf89dd7fc73a?q=80&w=1000';

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      exit="exit"
      variants={containerVariants}
      className="flex flex-col h-full"
    >
      <div className="relative h-48 overflow-hidden rounded-t-xl">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-purple-700"></div>
        <div className="absolute inset-0 bg-cover bg-center opacity-20" style={{ backgroundImage: `url(${imageUrl})` }}></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.h1 
            className="font-bold text-2xl md:text-3xl text-white text-center drop-shadow-md px-4"
            variants={itemVariants}
          >
            {storyPart.title}
          </motion.h1>
        </div>
      </div>
      
      <div className="p-6 flex-grow">
        <motion.div 
          className="prose prose-sm md:prose-base max-w-none mb-8 text-gray-700"
          variants={itemVariants}
        >
          <p className="whitespace-pre-line">{storyPart.description}</p>
        </motion.div>
        
        <AnimatePresence mode="wait">
          {showConsequence && consequence ? (
            <motion.div
              key="consequence"
              initial="hidden"
              animate="visible"
              exit="exit"
              variants={consequenceVariants}
              className="mb-6 p-4 bg-purple-50 border border-purple-200 rounded-lg text-sm text-purple-700"
            >
              <p className="font-medium mb-1">Sonuç:</p>
              <p>{consequence}</p>
            </motion.div>
          ) : (
            !readyToContinue && storyPart.choices && (
              <motion.div 
                key="choices"
                className="space-y-4"
                variants={itemVariants}
              >
                <h3 className="text-lg font-medium text-gray-800 mb-3">Ne yapacaksın?</h3>
                {storyPart.choices.map((choice, index) => (
                  <motion.div
                    key={index}
                    className={`p-4 border rounded-lg cursor-pointer transition-all duration-200 ${
                      selectedChoice === index 
                        ? 'border-purple-500 bg-purple-50' 
                        : 'border-gray-200 hover:border-purple-300 hover:bg-purple-50/30'
                    }`}
                    onClick={() => handleChoiceClick(choice, index)}
                    variants={choiceVariants}
                    animate={selectedChoice === index ? 'selected' : 'visible'}
                    whileHover={selectedChoice === null ? { scale: 1.02, boxShadow: '0 4px 8px rgba(0, 0, 0, 0.05)' } : {}}
                    whileTap={selectedChoice === null ? "tap" : {}}
                    transition={{ type: "spring", stiffness: 400, damping: 17 }}
                  >
                    {choice.text}
                  </motion.div>
                ))}
              </motion.div>
            )
          )}
          
          {readyToContinue && (
            <motion.div
              key="continue-button"
              className="flex justify-center mt-6"
              initial="hidden"
              animate="visible"
              variants={buttonVariants}
            >
              <motion.button
                onClick={handleContinue}
                className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium py-3 px-8 rounded-lg shadow-md transition-all"
                whileHover="hover"
                whileTap="tap"
              >
                İlerle
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};