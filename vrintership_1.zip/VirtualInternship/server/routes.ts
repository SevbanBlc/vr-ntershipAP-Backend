import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { InsertUserProgress, InsertUserStory } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // SESSION_SECRET ortam değişkenini kontrol et, yoksa varsayılan değer ata
  process.env.SESSION_SECRET = process.env.SESSION_SECRET || "vrintership-secret-key";
  
  // Auth sistemini kurulumunu yap
  setupAuth(app);

  // Kullanıcı ilerlemesini getir
  app.get("/api/progress", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Oturum açmanız gerekiyor");
    }

    try {
      const userId = req.user.id;
      const progress = await storage.getUserProgress(userId);
      res.json(progress || null);
    } catch (error) {
      console.error("Progress alma hatası:", error);
      res.status(500).send("İlerleme bilgisi alınamadı");
    }
  });

  // Kullanıcı ilerlemesi oluştur veya güncelle
  app.post("/api/progress", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Oturum açmanız gerekiyor");
    }

    try {
      const userId = req.user.id;
      
      // İlk olarak mevcut ilerleme var mı kontrol et
      const existingProgress = await storage.getUserProgress(userId);
      
      if (existingProgress) {
        // Mevcut ilerlemeyi güncelle
        const updatedProgress = await storage.updateUserProgress(
          existingProgress.id, 
          {...req.body, userId}
        );
        return res.json(updatedProgress);
      } else {
        // Yeni ilerleme oluştur
        const newProgress = await storage.createUserProgress({
          ...req.body,
          userId
        });
        return res.json(newProgress);
      }
    } catch (error) {
      console.error("Progress kaydetme hatası:", error);
      res.status(500).send("İlerleme bilgisi kaydedilemedi");
    }
  });

  // Kullanıcının hikaye bilgisini getir
  app.get("/api/stories", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Oturum açmanız gerekiyor");
    }

    try {
      const userId = req.user.id;
      const stories = await storage.getUserStories(userId);
      res.json(stories);
    } catch (error) {
      console.error("Hikaye alma hatası:", error);
      res.status(500).send("Hikaye bilgisi alınamadı");
    }
  });

  // Kullanıcı hikayesi oluştur veya güncelle
  app.post("/api/stories", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Oturum açmanız gerekiyor");
    }

    try {
      const userId = req.user.id;
      const { storyId, ...storyData } = req.body;
      
      if (storyId) {
        // Mevcut hikayeyi güncelle
        const updatedStory = await storage.updateUserStory(
          storyId, 
          {...storyData, userId}
        );
        return res.json(updatedStory);
      } else {
        // Yeni hikaye oluştur
        const newStory = await storage.createUserStory({
          ...storyData,
          userId
        });
        return res.json(newStory);
      }
    } catch (error) {
      console.error("Hikaye kaydetme hatası:", error);
      res.status(500).send("Hikaye bilgisi kaydedilemedi");
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
