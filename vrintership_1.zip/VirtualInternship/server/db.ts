import { neon, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-http';
import pg from 'pg';

// HTTP bağlantısı kullanarak Drizzle ORM için database connection oluşturma
neonConfig.fetchConnectionCache = true;

// Serverless HTTP connection
const sql = neon(process.env.DATABASE_URL!);
export const db = drizzle(sql);

// Regular pool connection for auth session store
export const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
});