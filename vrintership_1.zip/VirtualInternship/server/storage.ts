import { users, type User, type InsertUser, userProgress, type UserProgress, type InsertUserProgress, userStories, type UserStory, type InsertUserStory } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Kullanıcı işlemleri
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // İlerleme işlemleri
  getUserProgress(userId: number): Promise<UserProgress | undefined>;
  createUserProgress(progress: InsertUserProgress): Promise<UserProgress>;
  updateUserProgress(id: number, progress: Partial<InsertUserProgress>): Promise<UserProgress | undefined>;
  
  // Hikaye işlemleri
  getUserStories(userId: number): Promise<UserStory[]>;
  getUserStory(id: number): Promise<UserStory | undefined>;
  createUserStory(story: InsertUserStory): Promise<UserStory>;
  updateUserStory(id: number, story: Partial<InsertUserStory>): Promise<UserStory | undefined>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    // Constructor boş olabilir
  }
  
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  async getUserProgress(userId: number): Promise<UserProgress | undefined> {
    const [progress] = await db
      .select()
      .from(userProgress)
      .where(eq(userProgress.userId, userId));
    return progress;
  }
  
  async createUserProgress(progress: InsertUserProgress): Promise<UserProgress> {
    const [createdProgress] = await db
      .insert(userProgress)
      .values(progress)
      .returning();
    return createdProgress;
  }
  
  async updateUserProgress(id: number, updateData: Partial<InsertUserProgress>): Promise<UserProgress | undefined> {
    const [updatedProgress] = await db
      .update(userProgress)
      .set({
        ...updateData,
        updatedAt: new Date()
      })
      .where(eq(userProgress.id, id))
      .returning();
    return updatedProgress;
  }
  
  async getUserStories(userId: number): Promise<UserStory[]> {
    const stories = await db
      .select()
      .from(userStories)
      .where(eq(userStories.userId, userId));
    return stories;
  }
  
  async getUserStory(id: number): Promise<UserStory | undefined> {
    const [story] = await db
      .select()
      .from(userStories)
      .where(eq(userStories.id, id));
    return story;
  }
  
  async createUserStory(story: InsertUserStory): Promise<UserStory> {
    const [createdStory] = await db
      .insert(userStories)
      .values(story)
      .returning();
    return createdStory;
  }
  
  async updateUserStory(id: number, updateData: Partial<InsertUserStory>): Promise<UserStory | undefined> {
    const [updatedStory] = await db
      .update(userStories)
      .set({
        ...updateData,
        updatedAt: new Date()
      })
      .where(eq(userStories.id, id))
      .returning();
    return updatedStory;
  }
}

export const storage = new DatabaseStorage();