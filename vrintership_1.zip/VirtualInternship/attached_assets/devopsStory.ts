import { StoryPart } from '../types';

export const devopsStoryParts: StoryPart[] = [
  {
    title: "DevOps Merkezi",
    description: "CI/CD pipeline'ları ve monitoring ekranlarıyla dolu bir ortamdasın.",
    image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&q=80&w=1000",
     choices: [
      {
        text: "Devam",
      
      }
    ]
  },
  {
    title: "Deployment Krizi",
    description: "Production ortamında bir deployment hatası oluştu. Nasıl müdahale edeceksin?",
    image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&q=80&w=1000",
    choices: [
      {
        text: "Rollback yap",
        consequence: "Hızlı ama geçici bir çözüm.",
        score: { analysis: 3 }
      },
      {
        text: "Hotfix uygula",
        consequence: "Riskli ama kalıcı bir çözüm.",
        score: { analysis: 5 }
      }
    ]
  }
];