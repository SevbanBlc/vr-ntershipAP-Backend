import { StoryPart } from '../types';

export const gamedevStoryParts: StoryPart[] = [
  {
    title: "Game Studio",
    description: "Oyun geliştirme stüdyosundasın. Her yer karakter tasarımları ve prototiplerle dolu.",
    image: "https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&q=80&w=1000",
     choices: [
      {
        text: "Devam",
      
      }
    ]
  },
  {
    title: "Oyun Motoru Seçimi",
    description: "İlk projen için oyun motoru seçmen gerekiyor.",
    image: "https://images.unsplash.com/photo-1552820728-8b83bb6b773f?auto=format&fit=crop&q=80&w=1000",
    choices: [
      {
        text: "Unity ile başla",
        consequence: "Geniş topluluk desteği kazanırsın.",
        score: { analysis: 5 }
      },
      {
        text: "Unreal Engine seç",
        consequence: "Güçlü grafik özellikleri elde edersin.",
        score: { analysis: 4 }
      }
    ]
  }
];