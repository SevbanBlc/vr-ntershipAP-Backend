import React from 'react';
import { motion } from 'framer-motion';

interface ResultSectionProps {
  success: boolean;
  onRestart: () => void;
}

export const ResultSection: React.FC<ResultSectionProps> = ({ success, onRestart }) => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        when: "beforeChildren",
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  const iconVariants = {
    hidden: { scale: 0, opacity: 0 },
    visible: { 
      scale: 1, 
      opacity: 1,
      transition: { 
        type: "spring",
        stiffness: 260,
        damping: 20,
        delay: 0.3
      }
    },
    bounce: {
      y: [0, -10, 0],
      transition: {
        repeat: Infinity,
        duration: 2,
        ease: "easeInOut"
      }
    }
  };

  const buttonVariants = {
    hover: { 
      scale: 1.05,
      boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)"
    },
    tap: { scale: 0.95 }
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <div className="relative h-60 overflow-hidden rounded-t-xl">
        <div className={`absolute inset-0 bg-gradient-to-r ${
          success 
            ? 'from-green-500 to-green-600' 
            : 'from-red-500 to-red-600'
        }`}></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.div
            variants={iconVariants}
            animate={["visible", "bounce"]}
          >
            {success ? (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-24 w-24 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-24 w-24 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            )}
          </motion.div>
        </div>
        <div className="absolute inset-x-0 bottom-0 p-6 text-center">
          <motion.h1 
            variants={itemVariants}
            className="font-heading font-bold text-3xl text-white drop-shadow-md"
          >
            {success ? 'Başarı!' : 'Başarısız!'}
          </motion.h1>
        </div>
      </div>
      
      <div className="p-8 text-center">
        <motion.div 
          className="mb-8"
          variants={itemVariants}
        >
          <p className="text-gray-700 leading-relaxed">
            {success 
              ? 'Tebrikler! İlk staj gününü başarıyla tamamladın ve teknoloji kariyerinde ilk adımı attın.'
              : 'Maalesef stajını tamamlayamadın. Bazı seçimler beklenmeyen sonuçlar doğurabilir.'
            }
          </p>
        </motion.div>
        
        <motion.div 
          className="mt-8"
          variants={itemVariants}
        >
          <motion.button
            onClick={onRestart}
            className="bg-primary-600 hover:bg-primary-700 text-white font-medium py-3 px-8 rounded-full shadow-md transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-opacity-50"
            variants={buttonVariants}
            whileHover="hover"
            whileTap="tap"
          >
            Yeniden Başla
          </motion.button>
        </motion.div>
      </div>
    </motion.div>
  );
};
