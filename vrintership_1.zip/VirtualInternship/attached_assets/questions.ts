import { Question } from './types';

// Bu sorular HEXACO kişilik modeli, Holland Mesleki Tercih Envanteri ve 
// teknoloji sektöründeki uzman görüşlerine dayanarak hazırlanmıştır.
export const questions: Question[] = [
  {
    question: "Bir yazılım projesinde en çok hangi aşamada keyif alırsın?",
    answers: [
      { 
        text: "Kullanıcı deneyimini tasarlarken ve görsel arayüzler oluştururken", 
        score: {
          frontend: 5,
          ux: 4,
          gamedev: 3,
          backend: 1,
          communication: 4,
          analysis: 3
        }
      },
      { 
        text: "Sistemin altyapısını ve iş mantığını tasarlarken", 
        score: {
          backend: 5,
          database: 4,
          security: 3,
          frontend: 1,
          communication: 2,
          analysis: 5
        }
      },
      { 
        text: "Verileri analiz edip anlamlı sonuçlar çıkarırken", 
        score: {
          datascience: 5,
          database: 4,
          backend: 2,
          frontend: 1,
          communication: 3,
          analysis: 5
        }
      }
    ]
  },
  {
    question: "Karmaşık bir teknik problemle karşılaştığında genellikle nasıl yaklaşırsın?",
    answers: [
      { 
        text: "Problemi görselleştirip, kullanıcı perspektifinden çözmeye çalışırım", 
        score: {
          frontend: 5,
          ux: 4,
          gamedev: 3,
          backend: 2,
          communication: 4,
          analysis: 3
        }
      },
      { 
        text: "Sorunu parçalara böler ve sistematik şekilde analiz ederim", 
        score: {
          backend: 4,
          security: 5,
          database: 4,
          devops: 3,
          communication: 2,
          analysis: 5
        }
      },
      { 
        text: "Veri ve örüntüleri inceleyerek çözüm ararım", 
        score: {
          datascience: 5,
          database: 4,
          security: 3,
          frontend: 1,
          communication: 2,
          analysis: 5
        }
      }
    ]
  },
  {
    question: "Aşağıdaki senaryolardan hangisi seni daha çok motive eder?",
    answers: [
      { 
        text: "Kullanıcıların hayatını kolaylaştıracak yenilikçi arayüzler tasarlamak", 
        score: {
          frontend: 5,
          ux: 5,
          gamedev: 3,
          backend: 1,
          communication: 4,
          analysis: 3
        }
      },
      { 
        text: "Yüksek performanslı ve ölçeklenebilir sistemler geliştirmek", 
        score: {
          backend: 5,
          devops: 4,
          database: 4,
          frontend: 1,
          communication: 2,
          analysis: 5
        }
      },
      { 
        text: "Büyük veri setlerinden değerli içgörüler çıkarmak", 
        score: {
          datascience: 5,
          database: 4,
          backend: 2,
          frontend: 1,
          communication: 3,
          analysis: 5
        }
      }
    ]
  },
  {
    question: "Bir yazılım projesinde en çok hangi konulara önem verirsin?",
    answers: [
      { 
        text: "Kullanıcı deneyimi ve arayüz estetiği", 
        score: {
          frontend: 5,
          ux: 5,
          gamedev: 3,
          backend: 1,
          communication: 4,
          analysis: 3
        }
      },
      { 
        text: "Sistem güvenliği ve performans optimizasyonu", 
        score: {
          security: 5,
          backend: 4,
          devops: 4,
          frontend: 1,
          communication: 2,
          analysis: 5
        }
      },
      { 
        text: "Veri doğruluğu ve analitik yaklaşım", 
        score: {
          datascience: 5,
          database: 4,
          backend: 3,
          frontend: 1,
          communication: 2,
          analysis: 5
        }
      }
    ]
  },
  {
    question: "Yeni bir teknoloji öğrenirken hangi yaklaşımı tercih edersin?",
    answers: [
      { 
        text: "Pratik yaparak ve görsel örneklerle öğrenme", 
        score: {
          frontend: 4,
          ux: 4,
          gamedev: 3,
          backend: 2,
          communication: 3,
          analysis: 3
        }
      },
      { 
        text: "Teknik dokümantasyonu detaylıca inceleme", 
        score: {
          backend: 5,
          security: 4,
          database: 4,
          frontend: 2,
          communication: 2,
          analysis: 5
        }
      },
      { 
        text: "Veri ve istatistiklerle analiz etme", 
        score: {
          datascience: 5,
          database: 4,
          backend: 3,
          frontend: 1,
          communication: 2,
          analysis: 5
        }
      }
    ]
  }
];