import React, { useState, useEffect } from 'react';
import { StoryPart, StoryChoice } from '../types';
import { motion, AnimatePresence } from 'framer-motion';
import { ChoiceCard } from './ui/ChoiceCard';
import { ParallaxBackground } from './ui/ParallaxBackground';

interface StorySectionProps {
  storyPart: StoryPart;
  onChoice: (choice: StoryChoice) => void;
}

export const StorySection: React.FC<StorySectionProps> = ({ storyPart, onChoice }) => {
  const [isNewPart, setIsNewPart] = useState(true);

  useEffect(() => {
    // Set animation flag when story part changes
    setIsNewPart(true);
    const timer = setTimeout(() => setIsNewPart(false), 10);
    return () => clearTimeout(timer);
  }, [storyPart]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        when: "beforeChildren",
        staggerChildren: 0.2
      }
    }
  };

  const textVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  const choicesContainerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.4,
        staggerChildren: 0.1
      }
    }
  };

  return (
    <div>
      <motion.div 
        layout
        className="relative h-60 md:h-80 overflow-hidden rounded-t-xl"
      >
        <ParallaxBackground imageUrl={storyPart.image || 'https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?auto=format&fit=crop&q=80&w=1200'} />
        <div className="absolute inset-x-0 bottom-0 p-6">
          <AnimatePresence mode="wait">
            <motion.h1 
              key={`title-${storyPart.title}`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="font-heading font-bold text-3xl text-white drop-shadow-md"
            >
              {storyPart.title}
            </motion.h1>
          </AnimatePresence>
        </div>
      </motion.div>
      
      <motion.div 
        className="p-8"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <AnimatePresence mode="wait">
          <motion.div 
            key={`desc-${storyPart.title}`}
            className="mb-8"
            variants={textVariants}
            initial="hidden"
            animate="visible"
            exit={{ opacity: 0, y: -20 }}
          >
            <p className="text-gray-700 leading-relaxed">
              {storyPart.description}
            </p>
          </motion.div>
        </AnimatePresence>
        
        <motion.div 
          className="space-y-3"
          variants={choicesContainerVariants}
        >
          <AnimatePresence mode="wait">
            {storyPart.choices?.map((choice, index) => (
              <ChoiceCard
                key={`choice-${storyPart.title}-${index}`}
                text={choice.text}
                onClick={() => onChoice(choice)}
                delay={0.2 + (index * 0.1)}
              />
            ))}
          </AnimatePresence>
        </motion.div>
      </motion.div>
    </div>
  );
};
