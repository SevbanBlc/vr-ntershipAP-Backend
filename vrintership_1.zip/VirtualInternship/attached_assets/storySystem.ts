import { StoryPart, StoryDimension, StoryState, StoryPath } from '../types';

// Define all possible story states
export const storyStates: Record<string, StoryState> = {
  INITIAL: 'initial',
  IN_PROGRESS: 'in_progress',
  SUCCESS: 'success',
  FAILURE: 'failure'
};

// Define story paths with their requirements and consequences
export const storyPaths: Record<string, StoryPath> = {
  PROFESSIONAL: {
    id: 'professional',
    requiredScore: { analysis: 20, communication: 15 },
    consequences: {
      success: 'Profesyonel yaklaşımın takdir topladı.',
      failure: 'Daha fazla profesyonel gelişime ihtiyacın var.'
    }
  },
  CASUAL: {
    id: 'casual',
    requiredScore: { analysis: 15, communication: 20 },
    consequences: {
      success: 'Rahat tavırların ve iyi iletişimin beğeni topladı.',
      failure: 'İş ortamında daha profesyonel olmalısın.'
    }
  }
};

// Define story dimensions with clear transitions and requirements
export const storyDimensions: Record<string, StoryDimension> = {
  morning: {
    id: 'morning',
    title: 'Sabahın İlk Işıkları',
    transitions: ['breakfast'],
    requirements: null,
    state: storyStates.INITIAL
  },
  breakfast: {
    id: 'breakfast',
    title: 'Kahvaltı Seçimi',
    transitions: ['clothing'],
    requirements: {
      previousDimension: 'morning'
    },
    state: storyStates.IN_PROGRESS
  },
  clothing: {
    id: 'clothing',
    title: 'Kıyafet Seçimi',
    transitions: ['transport', 'team_choice'],
    requirements: {
      previousDimension: 'breakfast'
    },
    state: storyStates.IN_PROGRESS
  },
  team_choice: {
    id: 'team_choice',
    title: 'Takım Seçimi',
    transitions: ['transport'],
    requirements: {
      previousDimension: 'clothing'
    },
    state: storyStates.IN_PROGRESS
  },
  transport: {
    id: 'transport',
    title: 'Ulaşım',
    transitions: ['office_arrival', 'late_arrival'],
    requirements: {
      previousDimension: ['clothing', 'team_choice']
    },
    state: storyStates.IN_PROGRESS
  },
  office_arrival: {
    id: 'office_arrival',
    title: 'Ofise Varış',
    transitions: ['interview', 'failure'],
    requirements: {
      previousDimension: 'transport'
    },
    state: storyStates.IN_PROGRESS
  },
  late_arrival: {
    id: 'late_arrival',
    title: 'Geç Varış',
    transitions: ['failure'],
    requirements: {
      previousDimension: 'transport'
    },
    state: storyStates.IN_PROGRESS
  },
  interview: {
    id: 'interview',
    title: 'Mülakat',
    transitions: ['coding'],
    requirements: {
      previousDimension: 'office_arrival'
    },
    state: storyStates.IN_PROGRESS
  },
  coding: {
    id: 'coding',
    title: 'Kodlama',
    transitions: ['solution', 'testing'],
    requirements: {
      previousDimension: 'interview',
      minimumScore: { analysis: 15 }
    },
    state: storyStates.IN_PROGRESS
  },
  testing: {
    id: 'testing',
    title: 'Test',
    transitions: ['solution', 'completion'],
    requirements: {
      previousDimension: 'coding'
    },
    state: storyStates.IN_PROGRESS
  },
  solution: {
    id: 'solution',
    title: 'Çözüm',
    transitions: ['completion'],
    requirements: {
      minimumScore: { 
        analysis: 20,
        communication: 15
      }
    },
    state: storyStates.IN_PROGRESS
  },
  completion: {
    id: 'completion',
    title: 'Tamamlama',
    transitions: ['evening'],
    requirements: {
      previousDimension: 'solution'
    },
    state: storyStates.IN_PROGRESS
  },
  evening: {
    id: 'evening',
    title: 'Akşam',
    transitions: ['book_choice'],
    requirements: null,
    state: storyStates.IN_PROGRESS
  },
  book_choice: {
    id: 'book_choice',
    title: 'Kitap Seçimi',
    transitions: ['dream'],
    requirements: null,
    state: storyStates.IN_PROGRESS
  },
  dream: {
    id: 'dream',
    title: 'Rüya',
    transitions: ['dream_analysis'],
    requirements: {
      previousDimension: 'book_choice'
    },
    state: storyStates.IN_PROGRESS
  },
  failure: {
    id: 'failure',
    title: 'Başarısızlık',
    transitions: [],
    requirements: null,
    state: storyStates.FAILURE
  }
};

// Helper function to validate transition requirements
export const canTransition = (
  currentDimension: string,
  nextDimension: string,
  scores: { analysis: number; communication: number },
  path?: string
): boolean => {
  const nextDim = storyDimensions[nextDimension];
  if (!nextDim) return false;

  const requirements = nextDim.requirements;
  if (!requirements) return true;

  // Check previous dimension requirement
  if (requirements.previousDimension) {
    if (Array.isArray(requirements.previousDimension)) {
      if (!requirements.previousDimension.includes(currentDimension)) {
        return false;
      }
    } else if (requirements.previousDimension !== currentDimension) {
      return false;
    }
  }

  // Check minimum score requirements
  if (requirements.minimumScore) {
    if (requirements.minimumScore.analysis && scores.analysis < requirements.minimumScore.analysis) {
      return false;
    }
    if (requirements.minimumScore.communication && scores.communication < requirements.minimumScore.communication) {
      return false;
    }
  }

  // Check path requirement
  if (requirements.path && requirements.path !== path) {
    return false;
  }

  return true;
};

// Helper function to get next story part based on dimension and choice
export const getNextStoryPart = (
  currentDimension: string,
  choice: string,
  scores: { analysis: number; communication: number },
  path?: string
): string | null => {
  const dimension = storyDimensions[currentDimension];
  if (!dimension) return null;

  // Find valid transitions
  const validTransitions = dimension.transitions.filter(transition =>
    canTransition(currentDimension, transition, scores, path)
  );

  // Find the next dimension based on the choice and valid transitions
  const nextDimension = validTransitions.find(transition => 
    frontendStoryParts.find(part => 
      part.dimension === transition && 
      part.choices?.some(c => c.text === choice)
    )
  );

  return nextDimension || null;
};