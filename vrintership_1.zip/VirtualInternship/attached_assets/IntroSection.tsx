import React from 'react';
import { motion } from 'framer-motion';

interface IntroSectionProps {
  onStart: () => void;
}

export const IntroSection: React.FC<IntroSectionProps> = ({ onStart }) => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        when: "beforeChildren",
        staggerChildren: 0.2
      }
    }
  };

  const childVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5, ease: "easeOut" }
    }
  };

  const buttonVariants = {
    hover: { 
      scale: 1.05, 
      boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)" 
    },
    tap: { scale: 0.95 }
  };

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={containerVariants}
    >
      <div className="relative h-64 overflow-hidden rounded-t-xl">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-indigo-600"></div>
        <div 
          className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1607799279861-4dd421887fb3?auto=format&fit=crop&q=80&w=1200')] bg-cover bg-center opacity-30"
        ></div>
        <motion.div 
          className="absolute inset-0 flex items-center justify-center"
          animate={{ y: [0, -10, 0] }}
          transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
        >
          <h1 className="font-heading font-bold text-4xl md:text-5xl text-white text-center drop-shadow-md">
            VRIntership
          </h1>
        </motion.div>
      </div>
      
      <div className="p-8">
        <motion.h2 
          className="font-heading font-semibold text-2xl text-gray-800 mb-4"
          variants={childVariants}
        >
          Sanal Gerçeklikte Kariyerini Keşfet
        </motion.h2>
        
        <motion.p 
          className="text-gray-600 mb-6"
          variants={childVariants}
        >
          Teknoloji dünyasındaki kariyerini keşfetmek için interaktif bir sanal gerçeklik deneyimine hazır mısın? 
          Bu deneyimde, kişiliğine ve tercihlerine göre şekillenecek bir hikaye yaşayacak ve hangi teknoloji 
          kariyerinin sana en uygun olduğunu keşfedeceksin.
        </motion.p>
        
        <motion.div 
          className="flex justify-center mt-6"
          variants={childVariants}
        >
          <motion.button
            onClick={onStart}
            className="bg-primary-600 hover:bg-primary-700 text-white font-medium py-3 px-8 rounded-full shadow-md transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-opacity-50"
            variants={buttonVariants}
            whileHover="hover"
            whileTap="tap"
          >
            Maceraya Başla
          </motion.button>
        </motion.div>
      </div>
    </motion.div>
  );
};
