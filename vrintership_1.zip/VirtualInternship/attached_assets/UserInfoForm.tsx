import React, { useState, useRef, useEffect } from 'react';
import { UserData, Step } from '../types';
import { motion, AnimatePresence } from 'framer-motion';

interface UserInfoFormProps {
  userData: UserData;
  onUpdateUserData: (userData: UserData) => void;
  onSubmit: () => void;
  step: Step;
}

export const UserInfoForm: React.FC<UserInfoFormProps> = ({ 
  userData, 
  onUpdateUserData, 
  onSubmit,
  step 
}) => {
  const [nameError, setNameError] = useState('');
  const [ageError, setAgeError] = useState('');
  const nameInputRef = useRef<HTMLInputElement>(null);
  const ageInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (step === 'name' && nameInputRef.current) {
      nameInputRef.current.focus();
    } else if (step === 'age' && ageInputRef.current) {
      ageInputRef.current.focus();
    }
  }, [step]);

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdateUserData({ ...userData, name: e.target.value });
    if (e.target.value.trim()) {
      setNameError('');
    }
  };

  const handleAgeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const age = parseInt(e.target.value);
    onUpdateUserData({ ...userData, age: isNaN(age) ? 0 : age });
    if (e.target.value && age > 0) {
      setAgeError('');
    }
  };

  const handleNameSubmit = () => {
    if (!userData.name.trim()) {
      setNameError('Lütfen adınızı girin');
      if (nameInputRef.current) {
        nameInputRef.current.focus();
      }
      return;
    }
    onSubmit();
  };

  const handleAgeSubmit = () => {
    if (!userData.age || userData.age <= 0) {
      setAgeError('Lütfen geçerli bir yaş girin');
      if (ageInputRef.current) {
        ageInputRef.current.focus();
      }
      return;
    }
    onSubmit();
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        when: "beforeChildren",
        staggerChildren: 0.1
      }
    },
    exit: { opacity: 0, transition: { duration: 0.2 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.3 } }
  };

  const buttonVariants = {
    hover: { scale: 1.05, backgroundColor: "#6d28d9" },
    tap: { scale: 0.95 }
  };

  const handleKeyPress = (e: React.KeyboardEvent, isNameStep: boolean) => {
    if (e.key === 'Enter') {
      isNameStep ? handleNameSubmit() : handleAgeSubmit();
    }
  };

  return (
    <div>
      <div className="relative h-40 overflow-hidden rounded-t-xl">
        <div className="absolute inset-0 bg-gradient-to-r from-primary-600 to-secondary-600"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <h1 className="font-heading font-bold text-3xl text-white text-center drop-shadow-md">
            Hakkında Bilgi Ver
          </h1>
        </div>
      </div>
      
      <div className="p-8">
        <AnimatePresence mode="wait">
          {step === 'name' && (
            <motion.div
              key="name-step"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
            >
              <motion.h2 
                variants={itemVariants} 
                className="font-heading font-semibold text-xl text-gray-800 mb-4"
              >
                Adın ne?
              </motion.h2>
              
              <motion.div variants={itemVariants} className="mb-6">
                <input
                  ref={nameInputRef}
                  type="text"
                  value={userData.name}
                  onChange={handleNameChange}
                  onKeyPress={(e) => handleKeyPress(e, true)}
                  placeholder="Adını gir"
                  className={`w-full px-4 py-3 rounded-lg border ${
                    nameError ? 'border-red-500' : 'border-gray-300'
                  } focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-all duration-300`}
                />
                {nameError && (
                  <motion.p 
                    initial={{ opacity: 0 }} 
                    animate={{ opacity: 1 }} 
                    className="mt-2 text-sm text-red-600"
                  >
                    {nameError}
                  </motion.p>
                )}
              </motion.div>
              
              <motion.div variants={itemVariants} className="flex justify-end">
                <motion.button
                  onClick={handleNameSubmit}
                  className="bg-primary-600 text-white font-medium py-2 px-6 rounded-lg shadow-md transition-all duration-300"
                  variants={buttonVariants}
                  whileHover="hover"
                  whileTap="tap"
                >
                  İlerle
                </motion.button>
              </motion.div>
            </motion.div>
          )}
          
          {step === 'age' && (
            <motion.div
              key="age-step"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
            >
              <motion.h2 
                variants={itemVariants} 
                className="font-heading font-semibold text-xl text-gray-800 mb-4"
              >
                Yaşın kaç?
              </motion.h2>
              
              <motion.div variants={itemVariants} className="mb-6">
                <input
                  ref={ageInputRef}
                  type="number"
                  value={userData.age || ''}
                  onChange={handleAgeChange}
                  onKeyPress={(e) => handleKeyPress(e, false)}
                  placeholder="Yaşını gir"
                  min="13"
                  max="100"
                  className={`w-full px-4 py-3 rounded-lg border ${
                    ageError ? 'border-red-500' : 'border-gray-300'
                  } focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-all duration-300`}
                />
                {ageError && (
                  <motion.p 
                    initial={{ opacity: 0 }} 
                    animate={{ opacity: 1 }} 
                    className="mt-2 text-sm text-red-600"
                  >
                    {ageError}
                  </motion.p>
                )}
              </motion.div>
              
              <motion.div variants={itemVariants} className="flex justify-end">
                <motion.button
                  onClick={handleAgeSubmit}
                  className="bg-primary-600 text-white font-medium py-2 px-6 rounded-lg shadow-md transition-all duration-300"
                  variants={buttonVariants}
                  whileHover="hover"
                  whileTap="tap"
                >
                  İlerle
                </motion.button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
