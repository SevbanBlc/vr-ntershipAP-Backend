import { 
  users, 
  userProgress, 
  userStories,
  type User, 
  type InsertUser, 
  type UserProgress, 
  type InsertUserProgress,
  type UserStory,
  type InsertUserStory 
} from "@shared/schema";
import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import { eq } from 'drizzle-orm';

// PostgreSQL bağlantısı
const connectionString = process.env.DATABASE_URL!;
const client = postgres(connectionString);
const db = drizzle(client);

export interface IStorage {
  // Kullanıcı işlemleri
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // İlerleme işlemleri
  getUserProgress(userId: number): Promise<UserProgress | undefined>;
  createUserProgress(progress: InsertUserProgress): Promise<UserProgress>;
  updateUserProgress(id: number, progress: Partial<InsertUserProgress>): Promise<UserProgress | undefined>;
  
  // Hikaye işlemleri
  getUserStories(userId: number): Promise<UserStory[]>;
  getUserStory(id: number): Promise<UserStory | undefined>;
  createUserStory(story: InsertUserStory): Promise<UserStory>;
  updateUserStory(id: number, story: Partial<InsertUserStory>): Promise<UserStory | undefined>;
}

export class PostgresStorage implements IStorage {
  constructor() {}

  // Kullanıcı işlemleri
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  // İlerleme işlemleri
  async getUserProgress(userId: number): Promise<UserProgress | undefined> {
    const result = await db.select().from(userProgress).where(eq(userProgress.userId, userId)).limit(1);
    if (!result[0]) return undefined;
    
    // JSON alanları parse et
    return {
      ...result[0],
      scores: typeof result[0].scores === 'string' 
        ? JSON.parse(result[0].scores as string) 
        : result[0].scores,
      careerSuggestions: typeof result[0].careerSuggestions === 'string'
        ? JSON.parse(result[0].careerSuggestions as string)
        : result[0].careerSuggestions
    };
  }

  async createUserProgress(progress: InsertUserProgress): Promise<UserProgress> {
    const sanitizedProgress = {
      ...progress,
      scores: typeof progress.scores === 'object' 
        ? JSON.stringify(progress.scores) 
        : progress.scores,
      careerSuggestions: Array.isArray(progress.careerSuggestions)
        ? JSON.stringify(progress.careerSuggestions)
        : progress.careerSuggestions
    };

    const result = await db.insert(userProgress).values(sanitizedProgress).returning();
    
    // JSON alanları parse et
    return {
      ...result[0],
      scores: typeof result[0].scores === 'string' 
        ? JSON.parse(result[0].scores as string) 
        : result[0].scores,
      careerSuggestions: typeof result[0].careerSuggestions === 'string'
        ? JSON.parse(result[0].careerSuggestions as string)
        : result[0].careerSuggestions
    };
  }

  async updateUserProgress(id: number, progress: Partial<InsertUserProgress>): Promise<UserProgress | undefined> {
    const updateData: Record<string, any> = { 
      ...progress, 
      updatedAt: new Date() 
    };
    
    // JSON alanlarını işle
    if (progress.scores) {
      updateData.scores = typeof progress.scores === 'object'
        ? JSON.stringify(progress.scores)
        : progress.scores;
    }
    
    if (progress.careerSuggestions) {
      updateData.careerSuggestions = Array.isArray(progress.careerSuggestions)
        ? JSON.stringify(progress.careerSuggestions)
        : progress.careerSuggestions;
    }
    
    const result = await db.update(userProgress)
      .set(updateData)
      .where(eq(userProgress.id, id))
      .returning();
    
    if (!result[0]) return undefined;
    
    // JSON alanları parse et
    return {
      ...result[0],
      scores: typeof result[0].scores === 'string' 
        ? JSON.parse(result[0].scores as string) 
        : result[0].scores,
      careerSuggestions: typeof result[0].careerSuggestions === 'string'
        ? JSON.parse(result[0].careerSuggestions as string)
        : result[0].careerSuggestions
    };
  }

  // Hikaye işlemleri
  async getUserStories(userId: number): Promise<UserStory[]> {
    const stories = await db.select().from(userStories).where(eq(userStories.userId, userId));
    
    // JSON alanlarını parse et
    return stories.map(story => ({
      ...story,
      completedDimensions: typeof story.completedDimensions === 'string'
        ? JSON.parse(story.completedDimensions as string)
        : story.completedDimensions
    }));
  }

  async getUserStory(id: number): Promise<UserStory | undefined> {
    const result = await db.select().from(userStories).where(eq(userStories.id, id)).limit(1);
    if (!result[0]) return undefined;
    
    // JSON alanları parse et
    return {
      ...result[0],
      completedDimensions: typeof result[0].completedDimensions === 'string'
        ? JSON.parse(result[0].completedDimensions as string)
        : result[0].completedDimensions
    };
  }

  async createUserStory(story: InsertUserStory): Promise<UserStory> {
    const sanitizedStory = {
      ...story,
      completedDimensions: Array.isArray(story.completedDimensions)
        ? JSON.stringify(story.completedDimensions)
        : story.completedDimensions
    };
    
    const result = await db.insert(userStories).values(sanitizedStory).returning();
    
    // JSON alanları parse et
    return {
      ...result[0],
      completedDimensions: typeof result[0].completedDimensions === 'string'
        ? JSON.parse(result[0].completedDimensions as string)
        : result[0].completedDimensions
    };
  }

  async updateUserStory(id: number, story: Partial<InsertUserStory>): Promise<UserStory | undefined> {
    const updateData: Record<string, any> = {
      ...story,
      updatedAt: new Date()
    };
    
    // JSON alanlarını işle
    if (story.completedDimensions) {
      updateData.completedDimensions = Array.isArray(story.completedDimensions)
        ? JSON.stringify(story.completedDimensions)
        : story.completedDimensions;
    }
    
    const result = await db.update(userStories)
      .set(updateData)
      .where(eq(userStories.id, id))
      .returning();
    
    if (!result[0]) return undefined;
    
    // JSON alanları parse et
    return {
      ...result[0],
      completedDimensions: typeof result[0].completedDimensions === 'string'
        ? JSON.parse(result[0].completedDimensions as string)
        : result[0].completedDimensions
    };
  }
}

// Hafızada depolama için yedek sınıf (geliştirme amaçlı)
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private progress: Map<number, UserProgress>;
  private stories: Map<number, UserStory>;
  
  currentUserId: number;
  currentProgressId: number;
  currentStoryId: number;

  constructor() {
    this.users = new Map();
    this.progress = new Map();
    this.stories = new Map();
    
    this.currentUserId = 1;
    this.currentProgressId = 1;
    this.currentStoryId = 1;
  }

  // Kullanıcı işlemleri
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // İlerleme işlemleri
  async getUserProgress(userId: number): Promise<UserProgress | undefined> {
    return Array.from(this.progress.values()).find(
      (progress) => progress.userId === userId,
    );
  }

  async createUserProgress(insertProgress: InsertUserProgress): Promise<UserProgress> {
    const id = this.currentProgressId++;
    const now = new Date();
    const progress: UserProgress = { 
      ...insertProgress, 
      id, 
      createdAt: now, 
      updatedAt: now 
    };
    this.progress.set(id, progress);
    return progress;
  }

  async updateUserProgress(id: number, updateData: Partial<InsertUserProgress>): Promise<UserProgress | undefined> {
    const existingProgress = this.progress.get(id);
    if (!existingProgress) return undefined;
    
    const updatedProgress: UserProgress = { 
      ...existingProgress, 
      ...updateData,
      updatedAt: new Date()
    };
    this.progress.set(id, updatedProgress);
    return updatedProgress;
  }

  // Hikaye işlemleri
  async getUserStories(userId: number): Promise<UserStory[]> {
    return Array.from(this.stories.values()).filter(
      (story) => story.userId === userId,
    );
  }

  async getUserStory(id: number): Promise<UserStory | undefined> {
    return this.stories.get(id);
  }

  async createUserStory(insertStory: InsertUserStory): Promise<UserStory> {
    const id = this.currentStoryId++;
    const now = new Date();
    const story: UserStory = { 
      ...insertStory, 
      id, 
      createdAt: now, 
      updatedAt: now 
    };
    this.stories.set(id, story);
    return story;
  }

  async updateUserStory(id: number, updateData: Partial<InsertUserStory>): Promise<UserStory | undefined> {
    const existingStory = this.stories.get(id);
    if (!existingStory) return undefined;
    
    const updatedStory: UserStory = { 
      ...existingStory, 
      ...updateData,
      updatedAt: new Date() 
    };
    this.stories.set(id, updatedStory);
    return updatedStory;
  }
}

// PostgreSQL storage kullanımı için dışa aktarım
export const storage = new PostgresStorage();
