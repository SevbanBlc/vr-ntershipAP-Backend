import { StoryPart } from '../types';

export const backendStoryParts: StoryPart[] = [
  {
    title: "Sunucu Odası",
    description: "İlk iş günün için veri merkezine geldin. Etrafta yüzlerce sunucu var ve senin görevin bu sistemleri yönetmek.",
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&q=80&w=1000",
     choices: [
      {
        text: "Devam",
      
      }
    ]
  },
  {
    title: "İlk Görev",
    description: "Sistem yöneticisi sana ilk görevini veriyor: Yeni bir API endpoint'i oluşturman gerekiyor.",
    image: "https://images.unsplash.com/photo-1504639725590-34d0984388bd?auto=format&fit=crop&q=80&w=1000",
    choices: [
      {
        text: "REST API tasarla",
        consequence: "Modern ve esnek bir çözüm sunarsın.",
        score: { analysis: 5 }
      },
      {
        text: "SOAP servisi oluştur",
        consequence: "Eski ama güvenilir bir yol seçersin.",
        score: { analysis: 3 }
      }
    ]
  }
];