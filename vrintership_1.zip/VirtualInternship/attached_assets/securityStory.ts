import { StoryPart } from '../types';

export const securityStoryParts: StoryPart[] = [
  {
    title: "Güvenlik Merkezi",
    description: "Siber güvenlik operasyon merkezindesin. Ekranlar sürekli değişen tehdit analizleriyle dolu.",
    image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=1000",
     choices: [
      {
        text: "Devam",
      
      }
    ]
  },
  {
    title: "Güvenlik İhlali",
    description: "Sistemde bir güvenlik ihlali tespit edildi. Hızlı karar vermen gerekiyor.",
    image: "https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80&w=1000",
    choices: [
      {
        text: "Sistemi izole et",
        consequence: "Güvenli ama radikal bir çözüm.",
        score: { analysis: 5 }
      },
      {
        text: "Trafiği analiz et",
        consequence: "Detaylı ama zaman alan bir yaklaşım.",
        score: { analysis: 3 }
      }
    ]
  }
];