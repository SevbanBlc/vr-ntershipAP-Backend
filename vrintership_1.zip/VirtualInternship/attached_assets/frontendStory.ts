import { StoryPart } from '../types';

export const frontendStoryParts: StoryPart[] = [
  {
    title: "Sabahın İlk Işıkları",
    description: "Stajının ilk günü için sabahın erken saatlerinde uyanırsın. Heyecanın yüzünden gözlerin parıldar; bugünün kariyerinde yeni bir sayfa açacağına inanırsın. Yavaşça yatağından kalkar ve güne hazırlanmak üzere mutfağa doğru yönelirsin.",
    image: "https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?auto=format&fit=crop&q=80&w=1000",
    dimension: "morning",
    choices: [
      {
        text: "Devam",
        consequence: "Mutfağa doğru ilerliyorsun",
        nextDimension: "breakfast"
      }
    ]
  },
  {
    title: "Kahvaltı Seçimi",
    description: "Mutfağa geldiğinde kahvaltıda neler yiyeceğine karar vermen gerekiyor.",
    image: "https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?auto=format&fit=crop&q=80&w=1000",
    dimension: "breakfast",
    choices: [
      {
        text: "Güzel bir gevrek ile kahvaltı",
        consequence: "Enerjik bir başlangıç yaparsın.",
        score: { analysis: 5 },
        nextDimension: "clothing"
      },
      {
        text: "Simit çay ile klasik bir kahvaltı",
        consequence: "Geleneksel bir başlangıç yaparsın.",
        score: { analysis: 3 },
        nextDimension: "clothing"
      }
    ]
  },
  {
    title: "Kıyafet Seçimi",
    description: "Hazırlanmak üzere dolaba yöneldiğinde ne giyeceğine karar vermen gerekiyor.",
    image: "https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&q=80&w=1000",
    dimension: "clothing",
    choices: [
      {
        text: "Şık bir takım elbise",
        consequence: "Profesyonel bir görünüm elde edersin.",
        score: { analysis: 5 },
        nextDimension: "transport_suit"
      },
      {
        text: "Forma",
        consequence: "Rahat ama biraz fazla casual bir görünüm.",
        score: { analysis: 2 },
        nextDimension: "team_choice"
      }
    ]
  },
  {
    title: "Hangi Takım Forması?",
    description: "Madem forma giymeye karar verdin, hangi takımın formasını giyeceksin?",
    image: "https://images.unsplash.com/photo-1434648957308-5e6a859697e8?auto=format&fit=crop&q=80&w=1000",
    dimension: "team_choice",
    choices: [
      {
        text: "Beşiktaş",
        consequence: "Kara Kartal'ın formasıyla çıkıyorsun yola. Patron da koyu bir Beşiktaşlı!",
        score: { analysis: 3, communication: 5 },
        nextDimension: "bjk_arrival"
      },
      {
        text: "Galatasaray",
        consequence: "Aslan gibi hazırsın. Ama patron koyu bir Beşiktaşlı...",
        score: { analysis: 3 },
        nextDimension: "transport"
      }
    ]
  },
  {
    title: "Beşiktaş Formasıyla Varış",
    description: "Ofise vardığında patron seni büyük bir gülümsemeyle karşılıyor. 'Vay! Beşiktaşlı bir yazılımcı! Bak bu güzel oldu. Ben de koyu bir Beşiktaşlıyım. Hadi gel, sana projelerimizi göstereyim. Bu arada akşam derbi var, belki birlikte izleriz!' diyor. Patronla hemen kaynaşıyorsunuz.",
    image: "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&q=80&w=1000",
    dimension: "bjk_arrival",
    choices: [
      {
        text: "Devam",
        consequence: "Harika bir başlangıç yaptın!",
        score: { communication: 5 },
        nextDimension: "interview"
      }
    ]
  },
  {
    title: "Takım Elbise ile Ulaşım",
    description: "Şık takım elbisen ile ofise gitmen gerekiyor. Nasıl gideceksin?",
    image: "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&q=80&w=1000",
    dimension: "transport_suit",
    choices: [
      {
        text: "Metro ile git",
        consequence: "Zamanında ve şık bir şekilde varırsın.",
        score: { analysis: 5 },
        nextDimension: "office_arrival"
      },
      {
        text: "Yürüyerek git",
        consequence: "Biraz terlemiş olsan da zamanında varırsın.",
        score: { analysis: 3 },
        nextDimension: "office_arrival"
      }
    ]
  },
  {
    title: "Ulaşım Seçimi",
    description: "Ofise gitmen gerekiyor. Nasıl gideceksin?",
    image: "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&q=80&w=1000",
    dimension: "transport",
    choices: [
      {
        text: "Metro ile git",
        consequence: "Zamanında varırsın.",
        score: { analysis: 5 },
        nextDimension: "gs_arrival"
      },
      {
        text: "Yürüyerek git",
        consequence: "Geç kalırsın. Bu ilk gün için hiç iyi olmadı...",
        score: { analysis: 2 },
        nextDimension: "gs_arrival"
      }
    ]
  },
  {
    title: "Galatasaray Formasıyla Varış",
    description: "Ofise vardığında patron seni görür görmez yüzü asılıyor. 'Galatasaray forması ile mi geldin? Üstelik ilk iş gününde? Bu kabul edilemez. Maalesef seninle çalışamayacağız. Profesyonellikten bu kadar uzak birini ekibimizde istemiyoruz.' diyor ve seni kovuyor.",
    image: "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&q=80&w=1000",
    dimension: "gs_arrival",
    choices: [
      {
        text: "Üzgün bir şekilde ofisten ayrıl",
        consequence: "İlk iş deneyimin başlamadan bitti.",
        nextDimension: "failure"
      }
    ]
  },
  {
    title: "Normal Varış",
    description: "Ofise vardın. Patron seni profesyonel bir şekilde karşılıyor ve doğrudan işe odaklanıyor.",
    image: "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&q=80&w=1000",
    dimension: "office_arrival",
    choices: [
      {
        text: "Devam",
        nextDimension: "interview"
      }
    ]
  },
  {
    title: "Mülakat",
    description: "Patron seninle teknik bir mülakat yapmak istiyor. 'Şimdi öğrendiğin dersleri pratiğe dökme zamanı.' diyor.",
    image: "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&q=80&w=1000",
    dimension: "interview",
    choices: [
      {
        text: "Mülakata hazırlan",
        nextDimension: "coding"
      }
    ]
  }
];