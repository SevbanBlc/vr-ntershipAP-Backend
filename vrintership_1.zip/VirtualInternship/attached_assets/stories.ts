import { StoryPart } from './types';

export const frontendStoryParts: StoryPart[] = [
  {
    title: "Sabahın İlk Işıkları",
    description: "Stajının ilk günü için sabahın erken saatlerinde uyanırsın. Heyecanın yüzünden gözlerin parıldar; bugünün kariyerinde yeni bir sayfa açacağına inanırsın. Yavaşça yatağından kalkar ve güne hazırlanmak üzere mutfağa doğru yönelirsin.",
    image: "https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?auto=format&fit=crop&q=80&w=1000",
    dimension: "morning",
    choices: [
      {
        text: "Devam",
        consequence: "Mutfağa doğru ilerliyorsun",
        nextDimension: "breakfast"
      }
    ]
  },
  {
    title: "Kahvaltı Seçimi",
    description: "Mutfağa geldiğinde kahvaltıda neler yiyeceğine karar vermen gerekiyor.",
    image: "https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?auto=format&fit=crop&q=80&w=1000",
    dimension: "breakfast",
    choices: [
      {
        text: "Güzel bir gevrek ile kahvaltı",
        consequence: "Enerjik bir başlangıç yaparsın.",
        score: { analysis: 5 },
        nextDimension: "clothing"
      },
      {
        text: "Simit çay ile klasik bir kahvaltı",
        consequence: "Geleneksel bir başlangıç yaparsın.",
        score: { analysis: 3 },
        nextDimension: "clothing"
      }
    ]
  },
  {
    title: "Kıyafet Seçimi",
    description: "Hazırlanmak üzere dolaba yöneldiğinde ne giyeceğine karar vermen gerekiyor.",
    image: "https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&q=80&w=1000",
    dimension: "clothing",
    choices: [
      {
        text: "Şık bir takım elbise",
        consequence: "Profesyonel bir görünüm elde edersin.",
        score: { analysis: 5 },
        nextDimension: "transport_suit"
      },
      {
        text: "Forma",
        consequence: "Rahat ama biraz fazla casual bir görünüm.",
        score: { analysis: 2 },
        nextDimension: "team_choice"
      }
    ]
  },
  {
    title: "Hangi Takım Forması?",
    description: "Madem forma giymeye karar verdin, hangi takımın formasını giyeceksin?",
    image: "https://images.unsplash.com/photo-1434648957308-5e6a859697e8?auto=format&fit=crop&q=80&w=1000",
    dimension: "team_choice",
    choices: [
      {
        text: "Beşiktaş",
        consequence: "Kara Kartal'ın formasıyla çıkıyorsun yola. Patron da koyu bir Beşiktaşlı!",
        score: { analysis: 3, communication: 5 },
        nextDimension: "bjk_arrival"
      },
      {
        text: "Galatasaray",
        consequence: "Aslan gibi hazırsın. Ama patron koyu bir Beşiktaşlı...",
        score: { analysis: 3 },
        nextDimension: "transport"
      }
    ]
  },
  {
    title: "Beşiktaş Formasıyla Varış",
    description: "Ofise vardığında patron seni büyük bir gülümsemeyle karşılıyor. 'Vay! Beşiktaşlı bir yazılımcı! Bak bu güzel oldu. Ben de koyu bir Beşiktaşlıyım. Hadi gel, sana projelerimizi göstereyim. Bu arada akşam derbi var, belki birlikte izleriz!' diyor. Patronla hemen kaynaşıyorsunuz.",
    image: "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&q=80&w=1000",
    dimension: "bjk_arrival",
    choices: [
      {
        text: "Devam",
        consequence: "Harika bir başlangıç yaptın!",
        score: { communication: 5 },
        nextDimension: "interview"
      }
    ]
  },
  {
    title: "Takım Elbise ile Ulaşım",
    description: "Şık takım elbisen ile ofise gitmen gerekiyor. Nasıl gideceksin?",
    image: "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&q=80&w=1000",
    dimension: "transport_suit",
    choices: [
      {
        text: "Metro ile git",
        consequence: "Zamanında ve şık bir şekilde varırsın.",
        score: { analysis: 5 },
        nextDimension: "office_arrival"
      },
      {
        text: "Yürüyerek git",
        consequence: "Biraz terlemiş olsan da zamanında varırsın.",
        score: { analysis: 3 },
        nextDimension: "office_arrival"
      }
    ]
  },
  {
    title: "Ulaşım Seçimi",
    description: "Ofise gitmen gerekiyor. Nasıl gideceksin?",
    image: "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&q=80&w=1000",
    dimension: "transport",
    choices: [
      {
        text: "Metro ile git",
        consequence: "Zamanında varırsın.",
        score: { analysis: 5 },
        nextDimension: "gs_arrival"
      },
      {
        text: "Yürüyerek git",
        consequence: "Geç kalırsın. Bu ilk gün için hiç iyi olmadı...",
        score: { analysis: 2 },
        nextDimension: "gs_arrival"
      }
    ]
  },
  {
    title: "Galatasaray Formasıyla Varış",
    description: "Ofise vardığında patron seni görür görmez yüzü asılıyor. 'Galatasaray forması ile mi geldin? Üstelik ilk iş gününde? Bu kabul edilemez. Maalesef seninle çalışamayacağız. Profesyonellikten bu kadar uzak birini ekibimizde istemiyoruz.' diyor ve seni kovuyor.",
    image: "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&q=80&w=1000",
    dimension: "gs_arrival",
    choices: [
      {
        text: "Üzgün bir şekilde ofisten ayrıl",
        consequence: "İlk iş deneyimin başlamadan bitti.",
        nextDimension: "failure"
      }
    ]
  },
  {
    title: "Normal Varış",
    description: "Ofise vardın. Patron seni profesyonel bir şekilde karşılıyor ve doğrudan işe odaklanıyor.",
    image: "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&q=80&w=1000",
    dimension: "office_arrival",
    choices: [
      {
        text: "Devam",
        nextDimension: "interview"
      }
    ]
  },
  {
    title: "Mülakat Başlıyor",
    description: "Ofise vardığında, güvenli bir şekilde giriş yapıyorsun. Güvenlik görevlisi seni rehber alarak asansöre götürüyor. Ofisin içi ferah ve modern. Yüksek camlardan dışarıya manzara göz alıcı, ama sen odaklanman gereken yeri biliyorsun: Mülakat odası.",
    image: "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&q=80&w=1000",
    dimension: "interview",
    choices: [
      {
        text: "İK Yöneticisi ve Teknik Müdür ile tanış",
        nextDimension: "self_intro"
      }
    ]
  },
  {
    title: "Kendini Tanıt",
    description: "İK Yöneticisi gülümseyerek söze başlar: 'Merhaba, hoş geldin! Öncelikle seni burada görmek çok güzel. Mülakatımızı başlatmadan önce, biraz kendinden bahseder misin? Neler yapıyorsun, seni buraya getiren motivasyon nedir?'",
    image: "https://images.unsplash.com/photo-1573164574472-797cdf4a583a?auto=format&fit=crop&q=80&w=1000",
    dimension: "self_intro",
    choices: [
      {
        text: "Kendini detaylı ve özgüvenli bir şekilde tanıt",
        consequence: "İyi bir izlenim bırakırsın",
        score: { communication: 5 },
        nextDimension: "tech_questions"
      },
      {
        text: "Kısa ve öz bir şekilde kendini tanıt",
        consequence: "Yeterli bir izlenim bırakırsın, ama daha fazlası olabilirdi",
        score: { communication: 3 },
        nextDimension: "tech_questions"
      }
    ]
  },
  {
    title: "Teknik Sorular",
    description: "Teknik Müdür, bilgisayarını açarak soruları sırasıyla sormaya başlar: 'HTML'de semantik elementlerin kullanımının önemi nedir? Bir web sayfasında neden semantik etiketler kullanmalıyız?'",
    image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&q=80&w=1000",
    dimension: "tech_questions",
    choices: [
      {
        text: "Semantik etiketlerin önemini detaylı açıkla",
        consequence: "Teknik bilgini gösterirsin",
        score: { analysis: 5 },
        nextDimension: "practical_task"
      },
      {
        text: "Kısa bir açıklama yap",
        consequence: "Temel bilgini gösterirsin",
        score: { analysis: 3 },
        nextDimension: "practical_task"
      }
    ]
  },
  {
    title: "Pratik Görev",
    description: "Teknik Müdür bir ekranı göstererek: 'Şimdi sana bir sayfa gösteriyoruz. Basit bir sayfa tasarımını al ve bu sayfanın düzeninde HTML etiketleriyle iyileştirme yapmanı istiyoruz. Birkaç satırını değiştirebilir misin?'",
    image: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&q=80&w=1000",
    dimension: "practical_task",
    choices: [
      {
        text: "Hızlıca sayfada eksiklikleri gör ve düzenle",
        consequence: "Görevde başarılı olursun",
        score: { analysis: 5, communication: 3 },
        nextDimension: "feedback"
      },
      {
        text: "Düzenlemeleri yaparken zorlan ve yavaş ilerle",
        consequence: "Görevi tamamlarsın ama hızlı değilsin",
        score: { analysis: 3, communication: 2 },
        nextDimension: "feedback"
      }
    ]
  },
  {
    title: "Geribildirim Zamanı",
    description: "Mülakat sonunda, İK Yöneticisi gülümseyerek söze başlar: 'Gerçekten güzel bir başlangıç yaptın. Ancak biraz daha pratik yapman gerekebilir. HTML5'te semantik yapıyı biraz daha içselleştirmen, projelerinde bu yaklaşımları daha doğal bir şekilde kullanmanı sağlayacaktır.'",
    image: "https://images.unsplash.com/photo-1556155092-490a1ba16284?auto=format&fit=crop&q=80&w=1000",
    dimension: "feedback",
    choices: [
      {
        text: "Geribildirimi olumlu karşıla ve teşekkür et",
        consequence: "Profesyonel bir izlenim bırakırsın",
        score: { communication: 5 },
        nextDimension: "result"
      }
    ]
  },
  {
    title: "Mülakat Sonucu",
    description: "Teknik Müdür sonucu açıklıyor: 'Performansını değerlendirdik ve seni stajyer ekibimize kabul etmeye karar verdik! Tebrikler! Pazartesi günü başlayabilir misin?'",
    image: "https://images.unsplash.com/photo-1532619675605-1ede6c2ed2b0?auto=format&fit=crop&q=80&w=1000",
    dimension: "result",
    choices: [
      {
        text: "Memnuniyetle kabul et ve teşekkür et",
        consequence: "Staj programına kabul edildin!",
        score: { communication: 5 },
        nextDimension: "coding"
      }
    ]
  }
];

export const backendStoryParts: StoryPart[] = [
  {
    title: "Sunucu Odası",
    description: "İlk iş günün için veri merkezine geldin. Etrafta yüzlerce sunucu var ve senin görevin bu sistemleri yönetmek.",
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&q=80&w=1000",
     choices: [
      {
        text: "Devam",
      
      }
    ]
  },
  {
    title: "İlk Görev",
    description: "Sistem yöneticisi sana ilk görevini veriyor: Yeni bir API endpoint'i oluşturman gerekiyor.",
    image: "https://images.unsplash.com/photo-1504639725590-34d0984388bd?auto=format&fit=crop&q=80&w=1000",
    choices: [
      {
        text: "REST API tasarla",
        consequence: "Modern ve esnek bir çözüm sunarsın.",
        score: { analysis: 5 }
      },
      {
        text: "SOAP servisi oluştur",
        consequence: "Eski ama güvenilir bir yol seçersin.",
        score: { analysis: 3 }
      }
    ]
  }
];

export const databaseStoryParts: StoryPart[] = [
  {
    title: "Veri Dünyası",
    description: "Veritabanı yönetim merkezinde ilk günün. Milyonlarca veri kaydı senin sorumluluğunda.",
    image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&q=80&w=1000",
     choices: [
      {
        text: "Devam",
      
      }
    ]
  },
  {
    title: "Optimizasyon Görevi",
    description: "Sistem yavaşlamaya başladı ve sen bir sorgu optimizasyonu yapmalısın.",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=1000",
    choices: [
      {
        text: "İndeksleme yap",
        consequence: "Performans artışı sağlarsın.",
        score: { analysis: 5 }
      },
      {
        text: "Sorguyu yeniden yaz",
        consequence: "Geçici bir çözüm bulursun.",
        score: { analysis: 3 }
      }
    ]
  }
];

export const securityStoryParts: StoryPart[] = [
  {
    title: "Güvenlik Merkezi",
    description: "Siber güvenlik operasyon merkezindesin. Ekranlar sürekli değişen tehdit analizleriyle dolu.",
    image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=1000",
     choices: [
      {
        text: "Devam",
      
      }
    ]
  },
  {
    title: "Güvenlik İhlali",
    description: "Sistemde bir güvenlik ihlali tespit edildi. Hızlı karar vermen gerekiyor.",
    image: "https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80&w=1000",
    choices: [
      {
        text: "Sistemi izole et",
        consequence: "Güvenli ama radikal bir çözüm.",
        score: { analysis: 5 }
      },
      {
        text: "Trafiği analiz et",
        consequence: "Detaylı ama zaman alan bir yaklaşım.",
        score: { analysis: 3 }
      }
    ]
  }
];

export const devopsStoryParts: StoryPart[] = [
  {
    title: "DevOps Merkezi",
    description: "CI/CD pipeline'ları ve monitoring ekranlarıyla dolu bir ortamdasın.",
    image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&q=80&w=1000",
     choices: [
      {
        text: "Devam",
      
      }
    ]
  },
  {
    title: "Deployment Krizi",
    description: "Production ortamında bir deployment hatası oluştu. Nasıl müdahale edeceksin?",
    image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&q=80&w=1000",
    choices: [
      {
        text: "Rollback yap",
        consequence: "Hızlı ama geçici bir çözüm.",
        score: { analysis: 3 }
      },
      {
        text: "Hotfix uygula",
        consequence: "Riskli ama kalıcı bir çözüm.",
        score: { analysis: 5 }
      }
    ]
  }
];

export const gamedevStoryParts: StoryPart[] = [
  {
    title: "Game Studio",
    description: "Oyun geliştirme stüdyosundasın. Her yer karakter tasarımları ve prototiplerle dolu.",
    image: "https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&q=80&w=1000",
     choices: [
      {
        text: "Devam",
      
      }
    ]
  },
  {
    title: "Oyun Motoru Seçimi",
    description: "İlk projen için oyun motoru seçmen gerekiyor.",
    image: "https://images.unsplash.com/photo-1552820728-8b83bb6b773f?auto=format&fit=crop&q=80&w=1000",
    choices: [
      {
        text: "Unity ile başla",
        consequence: "Geniş topluluk desteği kazanırsın.",
        score: { analysis: 5 }
      },
      {
        text: "Unreal Engine seç",
        consequence: "Güçlü grafik özellikleri elde edersin.",
        score: { analysis: 4 }
      }
    ]
  }
];

export const datascienceStoryParts: StoryPart[] = [
  {
    title: "Veri Bilimi Laboratuvarı",
    description: "Veri bilimi laboratuvarındasın. Etrafta karmaşık algoritmalar ve büyük veri setleri var.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=1000",
    choices: [
      {
        text: "Devam",
      }
    ]
  },
  {
    title: "Model Seçimi",
    description: "Müşteri davranışlarını tahmin etmek için bir model geliştirmen gerekiyor.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=1000",
    choices: [
      {
        text: "Derin öğrenme kullan",
        consequence: "Karmaşık ama güçlü bir çözüm.",
        score: { analysis: 5 }
      },
      {
        text: "Klasik makine öğrenmesi kullan",
        consequence: "Daha anlaşılır bir model oluşturursun.",
        score: { analysis: 4 }
      }
    ]
  }
];

// İlk iş günü bölümü - Stajınız başladıktan sonra
export const firstDayStoryParts: StoryPart[] = [
  {
    title: "İlk İş Günü",
    description: "Staj programına kabul edildin ve ilk iş günün için ofise geldin. Masana yerleşiyor ve ekip arkadaşlarınla tanışıyorsun. Teknik lider sana ilk görevini veriyor.",
    image: "https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&q=80&w=1000",
    dimension: "coding",
    choices: [
      {
        text: "Devam",
        nextDimension: "first_task"
      }
    ]
  },
  {
    title: "İlk Görevin",
    description: "Teknik lider sana bir web sayfasının arayüzünü geliştirme görevi veriyor. 'Bu bizim yeni projemiz için bir landing page. Kullanıcı girişi, animasyonlar ve responsive tasarım üzerinde çalışmanı istiyoruz.' diyor.",
    image: "https://images.unsplash.com/photo-1531403009284-440f080d1e12?auto=format&fit=crop&q=80&w=1000",
    dimension: "first_task",
    choices: [
      {
        text: "Hemen kod yazmaya başla",
        consequence: "Aceleci davrandın ve planlamayı atladın.",
        score: { analysis: 2, communication: 2 },
        nextDimension: "coding_issue"
      },
      {
        text: "Önce tasarımı analiz et ve plan yap",
        consequence: "Sistemli yaklaştın ve sağlam bir başlangıç yaptın.",
        score: { analysis: 5, communication: 4 },
        nextDimension: "coding_success"
      }
    ]
  },
  {
    title: "Kod Yazma Sorunu",
    description: "Plansız bir şekilde hemen koda atlaman sorunlara yol açtı. Gittikçe karmaşıklaşan kod yapısı içinde kayboluyorsun ve CSS sorunlarıyla boğuşmaya başlıyorsun.",
    image: "https://images.unsplash.com/photo-1555099962-4199c345e5dd?auto=format&fit=crop&q=80&w=1000",
    dimension: "coding_issue",
    choices: [
      {
        text: "Mentöründen yardım iste",
        consequence: "Sorunları çözmek için yardım istemek akıllıca.",
        score: { communication: 5, analysis: 3 },
        nextDimension: "mentor_help"
      },
      {
        text: "Tek başına çözmeye devam et",
        consequence: "Saatlerce uğraşıyor ama ilerleme kaydedemiyorsun.",
        score: { communication: 1, analysis: 2 },
        nextDimension: "task_failure"
      }
    ]
  },
  {
    title: "Başarılı Kodlama",
    description: "Tasarımı iyi analiz etmen ve planlama yapman sayesinde kodlama süreci sorunsuz ilerliyor. Component yapısını düzgün kurarak temiz bir kod yazıyorsun.",
    image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&q=80&w=1000",
    dimension: "coding_success",
    choices: [
      {
        text: "Kodu tamamla ve test et",
        consequence: "Kaliteli bir iş çıkardın ve teknik lider etkilendi!",
        score: { analysis: 5, communication: 4 },
        nextDimension: "impress_leader"
      }
    ]
  },
  {
    title: "Mentör Yardımı",
    description: "Mentörün sana yaklaşarak: 'Her zaman önce planlama yapmak ve component yapısını düşünmek önemlidir. Hadi birlikte düzeltelim.' diyor. Onun yardımıyla kodu temizliyor ve düzenliyorsun.",
    image: "https://images.unsplash.com/photo-1543269865-cbf427effbad?auto=format&fit=crop&q=80&w=1000",
    dimension: "mentor_help",
    choices: [
      {
        text: "Yardım için teşekkür et ve dersi öğren",
        consequence: "Değerli bir tecrübe kazandın.",
        score: { communication: 5, analysis: 4 },
        nextDimension: "lesson_learned"
      }
    ]
  },
  {
    title: "Görev Başarısızlığı",
    description: "Yardım istemeden sorunu çözmeye çalışman deadline'ı kaçırmana neden oldu. Teknik lider durumdan memnun değil: 'Takım çalışması önemlidir. Zorlandığında yardım istemelisin.' diyor.",
    image: "https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80&w=1000",
    dimension: "task_failure",
    choices: [
      {
        text: "Özür dile ve dersini çıkar",
        consequence: "Hatandan ders çıkardın, bir sonraki görevde daha iyi olacaksın.",
        score: { communication: 4, analysis: 3 },
        nextDimension: "lesson_learned"
      }
    ]
  },
  {
    title: "Lideri Etkilemek",
    description: "Teknik lider senin kodunu inceliyor ve etkilendiğini belirtiyor: 'Temiz kod, iyi bir component yapısı ve responsive tasarım. Frontend için gerçekten yeteneklisin! Bir sonraki sprint için seni daha kapsamlı bir görevde değerlendirmek istiyorum.'",
    image: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=1000",
    dimension: "impress_leader",
    choices: [
      {
        text: "Yeni görevi heyecanla kabul et",
        consequence: "Kariyer yolunda emin adımlarla ilerliyorsun!",
        score: { communication: 5, analysis: 5 },
        nextDimension: "success"
      }
    ]
  },
  {
    title: "Alınan Ders",
    description: "Bu deneyim sana planlama, iletişim ve takım çalışmasının önemini öğretti. Bir sonraki görevinde bu derslerden faydalanacaksın.",
    image: "https://images.unsplash.com/photo-1507925921958-8a62f3d1a50d?auto=format&fit=crop&q=80&w=1000",
    dimension: "lesson_learned",
    choices: [
      {
        text: "Yeni bir gün, yeni bir görev",
        consequence: "Her hata ve deneyim seni daha iyi bir geliştirici yapıyor.",
        score: { communication: 4, analysis: 4 },
        nextDimension: "success"
      }
    ]
  }
];
