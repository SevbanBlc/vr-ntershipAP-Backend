import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertUserProgressSchema,
  insertUserStorySchema
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Kullanıcı API
  app.post("/api/users", async (req, res) => {
    try {
      const user = insertUserSchema.parse(req.body);
      const createdUser = await storage.createUser(user);
      res.status(201).json(createdUser);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Kullanıcı oluşturulurken hata oluştu" });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ error: "Kullanıcı bulunamadı" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Kullanıcı alınırken hata oluştu" });
    }
  });

  // İlerleme API
  app.post("/api/progress", async (req, res) => {
    try {
      const progress = insertUserProgressSchema.parse(req.body);
      const createdProgress = await storage.createUserProgress(progress);
      res.status(201).json(createdProgress);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "İlerleme oluşturulurken hata oluştu" });
    }
  });

  app.get("/api/progress/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const progress = await storage.getUserProgress(userId);
      if (!progress) {
        return res.status(404).json({ error: "İlerleme bulunamadı" });
      }
      res.json(progress);
    } catch (error) {
      res.status(500).json({ error: "İlerleme alınırken hata oluştu" });
    }
  });

  app.put("/api/progress/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const progressData = req.body;
      const updatedProgress = await storage.updateUserProgress(id, progressData);
      if (!updatedProgress) {
        return res.status(404).json({ error: "İlerleme bulunamadı" });
      }
      res.json(updatedProgress);
    } catch (error) {
      res.status(500).json({ error: "İlerleme güncellenirken hata oluştu" });
    }
  });

  // Hikaye API
  app.post("/api/stories", async (req, res) => {
    try {
      const story = insertUserStorySchema.parse(req.body);
      const createdStory = await storage.createUserStory(story);
      res.status(201).json(createdStory);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Hikaye oluşturulurken hata oluştu" });
    }
  });

  app.get("/api/stories/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const stories = await storage.getUserStories(userId);
      res.json(stories);
    } catch (error) {
      res.status(500).json({ error: "Hikayeler alınırken hata oluştu" });
    }
  });

  app.get("/api/story/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const story = await storage.getUserStory(id);
      if (!story) {
        return res.status(404).json({ error: "Hikaye bulunamadı" });
      }
      res.json(story);
    } catch (error) {
      res.status(500).json({ error: "Hikaye alınırken hata oluştu" });
    }
  });

  app.put("/api/story/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const storyData = req.body;
      const updatedStory = await storage.updateUserStory(id, storyData);
      if (!updatedStory) {
        return res.status(404).json({ error: "Hikaye bulunamadı" });
      }
      res.json(updatedStory);
    } catch (error) {
      res.status(500).json({ error: "Hikaye güncellenirken hata oluştu" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
