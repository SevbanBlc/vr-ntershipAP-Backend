import { StoryPart } from '../types';

export const databaseStoryParts: StoryPart[] = [
  {
    title: "Veri Dünyası",
    description: "Veritabanı yönetim merkezinde ilk günün. Milyonlarca veri kaydı senin sorumluluğunda.",
    image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&q=80&w=1000",
     choices: [
      {
        text: "Devam",
      
      }
    ]
  },
  {
    title: "Optimizasyon Görevi",
    description: "Sistem yavaşlamaya başladı ve sen bir sorgu optimizasyonu yapmalısın.",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=1000",
    choices: [
      {
        text: "İndeksleme yap",
        consequence: "Performans artışı sağlarsın.",
        score: { analysis: 5 }
      },
      {
        text: "Sorguyu yeniden yaz",
        consequence: "Geçici bir çözüm bulursun.",
        score: { analysis: 3 }
      }
    ]
  }
];