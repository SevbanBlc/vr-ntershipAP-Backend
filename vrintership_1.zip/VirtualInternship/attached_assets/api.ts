import { apiRequest } from '../lib/queryClient';
import type { 
  UserData, 
  Step, 
  Scores, 
  CareerSuggestion,
  StoryChoice
} from '../types';

// Veritabanındaki kullanıcı için arayüz
export interface DbUser {
  id: number;
  username: string;
  password: string;
  name: string | null;
  age: number | null;
}

// Veritabanındaki ilerleme için arayüz
export interface DbUserProgress {
  id: number;
  userId: number;
  currentStep: string;
  scores: Record<string, number>;
  careerSuggestions: string[];
  selectedCareer: string | null;
  currentStoryPart: number | null;
  currentDimension: string | null;
  createdAt: Date | null;
  updatedAt: Date | null;
}

// Veritabanındaki hikaye için arayüz
export interface DbUserStory {
  id: number;
  userId: number;
  storyPath: string;
  completedDimensions: string[];
  success: number | null;
  createdAt: Date | null;
  updatedAt: Date | null;
}

// Kullanıcı oluşturma
export async function createUser(userData: UserData): Promise<DbUser> {
  const res = await apiRequest('POST', '/api/users', {
    username: userData.name.toLowerCase().replace(/\s+/g, '_') + Math.floor(Math.random() * 1000),
    password: 'vrintership' + Math.floor(Math.random() * 100000),
    name: userData.name,
    age: userData.age
  });
  return await res.json();
}

// Kullanıcı ilerleme oluşturma
export async function createUserProgress(
  userId: number, 
  step: Step, 
  scores: Scores,
  careerSuggestions: string[] = [],
  selectedCareer: string = '',
  currentStoryPart: number = 0,
  currentDimension: string = 'morning'
): Promise<DbUserProgress> {
  const res = await apiRequest('POST', '/api/progress', {
    userId,
    currentStep: step,
    scores,
    careerSuggestions,
    selectedCareer: selectedCareer || null,
    currentStoryPart,
    currentDimension
  });
  return await res.json();
}

// Kullanıcı ilerleme güncelleme
export async function updateUserProgress(
  progressId: number,
  data: Partial<{
    currentStep: Step;
    scores: Scores;
    careerSuggestions: string[];
    selectedCareer: string;
    currentStoryPart: number;
    currentDimension: string;
  }>
): Promise<DbUserProgress> {
  const res = await apiRequest('PUT', `/api/progress/${progressId}`, data);
  return await res.json();
}

// Kullanıcı hikaye oluşturma
export async function createUserStory(
  userId: number,
  storyPath: string,
  completedDimensions: string[] = [],
  success: number = 0
): Promise<DbUserStory> {
  const res = await apiRequest('POST', '/api/stories', {
    userId,
    storyPath,
    completedDimensions,
    success
  });
  return await res.json();
}

// Kullanıcı hikaye güncelleme
export async function updateUserStory(
  storyId: number,
  data: Partial<{
    storyPath: string;
    completedDimensions: string[];
    success: number;
  }>
): Promise<DbUserStory> {
  const res = await apiRequest('PUT', `/api/stories/${storyId}`, data);
  return await res.json();
}

// Kullanıcı hikayelerini getirme
export async function getUserStories(userId: number): Promise<DbUserStory[]> {
  const res = await fetch(`/api/stories/${userId}`, {
    credentials: "include",
  });
  if (!res.ok) {
    throw new Error('Hikayeler alınamadı');
  }
  return await res.json();
}

// Kullanıcı ilerleme bilgisini getirme
export async function getUserProgress(userId: number): Promise<DbUserProgress | null> {
  const res = await fetch(`/api/progress/${userId}`, {
    credentials: "include",
  });
  if (res.status === 404) {
    return null;
  }
  if (!res.ok) {
    throw new Error('İlerleme bilgisi alınamadı');
  }
  return await res.json();
}