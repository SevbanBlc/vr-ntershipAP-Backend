import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name"),
  age: integer("age"),
});

export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  currentStep: text("current_step").notNull(), // intro, name, age, psychologist, questions, analysis, results...
  scores: jsonb("scores").notNull().$type<Record<string, number>>(),
  careerSuggestions: jsonb("career_suggestions").notNull().$type<string[]>(),
  selectedCareer: text("selected_career"),
  currentStoryPart: integer("current_story_part").default(0),
  currentDimension: text("current_dimension").default('morning'),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const userStories = pgTable("user_stories", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  storyPath: text("story_path").notNull(), // frontend, backend, database, security, devops, gamedev, datascience
  completedDimensions: jsonb("completed_dimensions").notNull().$type<string[]>(),
  success: integer("success").default(0), // 0 = in progress, 1 = success, -1 = failure
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  age: true,
});

export const insertUserProgressSchema = createInsertSchema(userProgress).pick({
  userId: true,
  currentStep: true,
  scores: true,
  careerSuggestions: true,
  selectedCareer: true,
  currentStoryPart: true,
  currentDimension: true,
});

export const insertUserStorySchema = createInsertSchema(userStories).pick({
  userId: true,
  storyPath: true,
  completedDimensions: true,
  success: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertUserProgress = z.infer<typeof insertUserProgressSchema>;
export type UserProgress = typeof userProgress.$inferSelect;

export type InsertUserStory = z.infer<typeof insertUserStorySchema>;
export type UserStory = typeof userStories.$inferSelect;
