import React, { useState, useEffect } from 'react';
import { CareerSuggestion } from '../types';
import { motion, AnimatePresence } from 'framer-motion';
import { Typewriter } from './ui/Typewriter';

interface AnalysisSectionProps {
  analysisText: string[];
  currentStep: number;
  careerSuggestions: CareerSuggestion[];
  onCareerSelect: (career: string) => void;
}

export const AnalysisSection: React.FC<AnalysisSectionProps> = ({
  analysisText,
  currentStep,
  careerSuggestions,
  onCareerSelect
}) => {
  const [showSuggestions, setShowSuggestions] = useState(false);
  
  useEffect(() => {
    if (currentStep >= analysisText.length - 1) {
      const timer = setTimeout(() => setShowSuggestions(true), 1500);
      return () => clearTimeout(timer);
    }
  }, [currentStep, analysisText.length]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        when: "beforeChildren",
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: (custom: number) => ({
      opacity: 1,
      y: 0,
      transition: { 
        delay: 0.2 * custom,
        duration: 0.5 
      }
    }),
    hover: { 
      y: -5,
      boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
      transition: { duration: 0.2 }
    },
    tap: { scale: 0.98 }
  };

  return (
    <div>
      <div className="relative h-40 overflow-hidden rounded-t-xl">
        <div className="absolute inset-0 bg-gradient-to-r from-primary-700 to-secondary-800"></div>
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1626379953822-baec19c3accd?auto=format&fit=crop&q=80&w=1200')] bg-cover bg-center opacity-20"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.h1 
            className="font-heading font-bold text-3xl text-white text-center drop-shadow-md"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.5 }}
          >
            Sonuçlar Analiz Ediliyor
          </motion.h1>
        </div>
      </div>
      
      <div className="p-8">
        <motion.div
          initial="hidden"
          animate="visible"
          variants={containerVariants}
        >
          <AnimatePresence>
            {analysisText.map((text, index) => (
              index <= currentStep && (
                <motion.div 
                  className="mb-6"
                  key={`analysis-step-${index}`}
                  variants={itemVariants}
                  initial="hidden"
                  animate="visible"
                  exit={{ opacity: 0 }}
                >
                  <div className="flex space-x-4">
                    <div className="flex-shrink-0">
                      <motion.div 
                        className="w-16 h-16 rounded-full bg-gray-300 flex items-center justify-center overflow-hidden"
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ type: "spring", stiffness: 260, damping: 20, delay: 0.2 }}
                      >
                        <img src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=300" alt="Dr. Bimlo" className="w-full h-full object-cover" />
                      </motion.div>
                    </div>
                    <div className="flex-grow bg-gray-100 rounded-2xl p-4">
                      {index === currentStep ? (
                        <Typewriter text={text} delay={20} />
                      ) : (
                        <p>{text}</p>
                      )}
                    </div>
                  </div>
                  
                  {index === 0 && currentStep === 0 && (
                    <div className="flex justify-center my-6">
                      <motion.div 
                        className="flex space-x-2"
                        animate={{ scale: [1, 1.1, 1] }}
                        transition={{ repeat: Infinity, duration: 1.5 }}
                      >
                        <motion.div 
                          className="h-3 w-3 bg-primary-400 rounded-full" 
                          animate={{ opacity: [0.5, 1, 0.5] }}
                          transition={{ repeat: Infinity, duration: 1, delay: 0 }}
                        />
                        <motion.div 
                          className="h-3 w-3 bg-primary-500 rounded-full" 
                          animate={{ opacity: [0.5, 1, 0.5] }}
                          transition={{ repeat: Infinity, duration: 1, delay: 0.2 }}
                        />
                        <motion.div 
                          className="h-3 w-3 bg-primary-600 rounded-full" 
                          animate={{ opacity: [0.5, 1, 0.5] }}
                          transition={{ repeat: Infinity, duration: 1, delay: 0.4 }}
                        />
                      </motion.div>
                    </div>
                  )}
                </motion.div>
              )
            ))}
          </AnimatePresence>
          
          <AnimatePresence>
            {showSuggestions && careerSuggestions.length > 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                <motion.h3 
                  className="font-heading font-semibold text-xl text-gray-800 mb-4"
                  variants={itemVariants}
                >
                  Kariyer Önerileri
                </motion.h3>
                
                <div className="grid md:grid-cols-3 gap-4">
                  {careerSuggestions.map((career, index) => (
                    <motion.div
                      key={`career-${index}`}
                      custom={index}
                      variants={cardVariants}
                      whileHover="hover"
                      whileTap="tap"
                      onClick={() => onCareerSelect(career.title)}
                      className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-md cursor-pointer"
                    >
                      <div className={`bg-gradient-to-r ${getGradientColor(index)} text-white p-4`}>
                        <h4 className="font-heading font-semibold text-lg">{career.title}</h4>
                        <div className="flex items-center mt-1">
                          <div className="w-full h-2 bg-white bg-opacity-30 rounded-full">
                            <motion.div 
                              className="h-2 bg-white rounded-full"
                              initial={{ width: 0 }}
                              animate={{ width: `${career.matchPercentage}%` }}
                              transition={{ duration: 1, delay: 0.5 }}
                            />
                          </div>
                          <span className="ml-2 text-sm">{career.matchPercentage}%</span>
                        </div>
                      </div>
                      <div className="p-4">
                        <p className="text-sm text-gray-600 mb-2">{career.description}</p>
                        <div className="mb-3">
                          <p className="text-xs font-semibold text-gray-700 mb-1">Gereken Beceriler:</p>
                          <div className="flex flex-wrap gap-1">
                            {career.requiredSkills.slice(0, 3).map((skill, i) => (
                              <span 
                                key={`skill-${i}`} 
                                className={`text-xs ${getSkillBadgeColor(index)} px-2 py-1 rounded`}
                              >
                                {skill}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
                
                <motion.div 
                  className="mt-6 text-center"
                  variants={itemVariants}
                >
                  <p className="text-gray-600 mb-4">Hangi kariyer yolunu daha detaylı incelemek istersin?</p>
                  <p className="text-sm text-gray-500 mb-6">Seçtiğin kariyer yolu için bir staj deneyimi yaşayacaksın.</p>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </div>
  );
};

// Helper functions for the component
function getGradientColor(index: number): string {
  const gradients = [
    "from-primary-500 to-primary-600",
    "from-secondary-500 to-secondary-600",
    "from-accent-500 to-accent-600"
  ];
  return gradients[index % gradients.length];
}

function getSkillBadgeColor(index: number): string {
  const badges = [
    "bg-primary-100 text-primary-700",
    "bg-secondary-100 text-secondary-700",
    "bg-accent-100 text-accent-700"
  ];
  return badges[index % badges.length];
}
