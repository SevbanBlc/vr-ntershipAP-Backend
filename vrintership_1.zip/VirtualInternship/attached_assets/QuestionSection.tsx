import React, { useState } from 'react';
import { Question, Answer } from '../types';
import { motion, AnimatePresence } from 'framer-motion';
import { ProgressBar } from './ui/ProgressBar';
import { ChoiceCard } from './ui/ChoiceCard';

interface QuestionSectionProps {
  currentQuestion: number;
  totalQuestions: number;
  question: Question;
  onAnswerSelect: (answer: Answer) => void;
}

export const QuestionSection: React.FC<QuestionSectionProps> = ({
  currentQuestion,
  totalQuestions,
  question,
  onAnswerSelect
}) => {
  const [selectedAnswerIndex, setSelectedAnswerIndex] = useState<number | null>(null);
  const progress = ((currentQuestion + 1) / totalQuestions) * 100;

  const handleAnswerClick = (answer: Answer, index: number) => {
    setSelectedAnswerIndex(index);
    
    // Delay the progression to next question to allow for animation
    setTimeout(() => {
      onAnswerSelect(answer);
      setSelectedAnswerIndex(null);
    }, 600);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        when: "beforeChildren",
        staggerChildren: 0.1
      }
    },
    exit: { opacity: 0 }
  };

  const questionVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.4 }
    }
  };

  return (
    <div>
      <div className="relative h-40 overflow-hidden rounded-t-xl">
        <div className="absolute inset-0 bg-gradient-to-r from-secondary-600 to-accent-500"></div>
        <div className="absolute inset-0 flex items-center justify-center flex-col">
          <motion.h1 
            className="font-heading font-bold text-3xl text-white text-center drop-shadow-md mb-2"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Yetenek Değerlendirmesi
          </motion.h1>
          
          <div className="w-64 h-2 bg-white bg-opacity-30 rounded-full overflow-hidden">
            <ProgressBar progress={progress} />
          </div>
          
          <motion.p 
            className="text-white mt-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
          >
            <span>{currentQuestion + 1}</span>/<span>{totalQuestions}</span>
          </motion.p>
        </div>
      </div>
      
      <div className="p-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={`question-${currentQuestion}`}
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
          >
            <motion.h2 
              className="font-heading font-semibold text-xl text-gray-800 mb-6"
              variants={questionVariants}
            >
              {question.question}
            </motion.h2>
            
            <div className="space-y-4">
              {question.answers.map((answer, index) => (
                <ChoiceCard 
                  key={index}
                  text={answer.text}
                  isSelected={selectedAnswerIndex === index}
                  onClick={() => handleAnswerClick(answer, index)}
                  delay={0.2 + (index * 0.1)}
                />
              ))}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
};
