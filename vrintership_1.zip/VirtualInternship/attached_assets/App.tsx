import React, { useState, useEffect } from 'react';
import { UserData, Step, Answer, Scores, StoryChoice, CareerSuggestion } from './types';
import { questions } from './questions';
import { 
  frontendStoryParts,
  backendStoryParts,
  databaseStoryParts,
  securityStoryParts,
  devopsStoryParts,
  gamedevStoryParts,
  datascienceStoryParts
} from './stories';

import { IntroSection } from './components/IntroSection';
import { UserInfoForm } from './components/UserInfoForm';
import { PsychologistStory } from './components/PsychologistStory';
import { QuestionSection } from './components/QuestionSection';
import { AnalysisSection } from './components/AnalysisSection';
import { ResultSection } from './components/ResultSection';
import { StorySection } from './components/StorySection';

function App() {
  const [step, setStep] = useState<Step>('intro');
  const [userData, setUserData] = useState<UserData>({ name: '', age: 0 });
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [scores, setScores] = useState<Scores>({});
  const [analysisStep, setAnalysisStep] = useState(0);
  const [careerSuggestions, setCareerSuggestions] = useState<CareerSuggestion[]>([]);
  const [selectedCareer, setSelectedCareer] = useState<string>('');
  const [currentStoryPart, setCurrentStoryPart] = useState(0);
  const [currentDimension, setCurrentDimension] = useState('morning');
  const [isGalatasarayFan, setIsGalatasarayFan] = useState(false);

  const getStoryPartsForCareer = () => {
    switch (selectedCareer) {
      case 'Frontend Developer':
        return frontendStoryParts;
      case 'Backend Developer':
        return backendStoryParts;
      case 'Database Engineer':
        return databaseStoryParts;
      case 'Security Engineer':
        return securityStoryParts;
      case 'DevOps Engineer':
        return devopsStoryParts;
      case 'Game Developer':
        return gamedevStoryParts;
      case 'Data Scientist':
        return datascienceStoryParts;
      default:
        return frontendStoryParts;
    }
  };

  const calculateScorePercentage = (area: string): number => {
    const maxPossibleScore = questions.length * 5;
    const actualScore = scores[area] || 0;
    return Math.round((actualScore / maxPossibleScore) * 100);
  };

  const getCareerSuggestions = (): CareerSuggestion[] => {
    const areas = [
      {
        id: 'frontend',
        title: 'Frontend Developer',
        description: 'Kullanıcı arayüzleri ve web uygulamaları geliştirme konusunda yeteneklisin.',
        skills: ['HTML/CSS', 'JavaScript', 'React/Vue/Angular', 'UI/UX Principles'],
        growth: ['Backend Integration', 'Performance Optimization', 'Responsive Design']
      },
      {
        id: 'backend',
        title: 'Backend Developer',
        description: 'Sistem mimarisi ve sunucu tarafı geliştirme konularında başarılısın.',
        skills: ['Node.js/Python/Java', 'Databases', 'API Design', 'System Architecture'],
        growth: ['Security', 'Scalability', 'Cloud Services']
      },
      {
        id: 'database',
        title: 'Database Engineer',
        description: 'Veri yönetimi ve veritabanı sistemleri konusunda güçlü yeteneklerin var.',
        skills: ['SQL/NoSQL', 'Database Design', 'Data Modeling', 'Performance Tuning'],
        growth: ['Big Data', 'Data Warehousing', 'Database Security']
      },
      {
        id: 'security',
        title: 'Security Engineer',
        description: 'Güvenlik sistemleri ve risk analizi konularında başarılısın.',
        skills: ['Network Security', 'Cryptography', 'Security Protocols', 'Penetration Testing'],
        growth: ['Cloud Security', 'Threat Analysis', 'Security Architecture']
      },
      {
        id: 'devops',
        title: 'DevOps Engineer',
        description: 'Sistem yönetimi ve otomasyonda güçlü yeteneklerin var.',
        skills: ['CI/CD', 'Docker/Kubernetes', 'Cloud Platforms', 'Infrastructure as Code'],
        growth: ['Site Reliability', 'Monitoring', 'Cloud Architecture']
      },
      {
        id: 'datascience',
        title: 'Data Scientist',
        description: 'Veri analizi ve makine öğrenmesi konularında potansiyelin var.',
        skills: ['Python', 'Statistics', 'Machine Learning', 'Data Analysis'],
        growth: ['Deep Learning', 'Big Data', 'Data Visualization']
      }
    ];

    const scoredAreas = areas.map(area => ({
      ...area,
      score: calculateScorePercentage(area.id),
      communication: scores.communication || 0,
      analysis: scores.analysis || 0
    }))
    .filter(area => area.score > 0);

    scoredAreas.sort((a, b) => b.score - a.score);

    return scoredAreas.slice(0, 3).map(area => ({
      title: area.title,
      description: area.description,
      matchPercentage: area.score,
      requiredSkills: area.skills,
      growthAreas: area.growth
    }));
  };

  const getAnalysisText = () => {
    const suggestions = getCareerSuggestions();
    if (suggestions.length === 0) {
      return [
        "Dr. Bimlo, test sonuçlarını dikkatle inceliyor...",
        "Senin teknik yeteneklerin ve ilgi alanların üzerine notlar alıyor...",
        `${userData.name}, senin profilin henüz belirli bir alana yönelmemiş görünüyor.`,
        "Biraz daha deneyim kazanman ve farklı alanları keşfetmen faydalı olabilir.",
      ];
    }
    return [
      "Dr. Bimlo, test sonuçlarını dikkatle inceliyor...",
      "Senin teknik yeteneklerin ve ilgi alanların üzerine notlar alıyor...",
      `${userData.name}, senin profilin oldukça ilginç. Hem teknik hem de iletişim becerilerinde güçlü yönlerin var.`,
      "Analizlerime göre, birkaç farklı alanda başarılı olabilirsin. İşte sana en uygun kariyer yolları:",
    ];
  };

  const handleAnswerSelect = (answer: Answer) => {
    const newScores = { ...scores };
    Object.keys(answer.score).forEach(key => {
      newScores[key] = (newScores[key] || 0) + answer.score[key];
    });
    setScores(newScores);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setStep('analysis');
      startAnalysis();
    }
  };

  const startAnalysis = () => {
    let step = 0;
    const suggestions = getCareerSuggestions();
    setCareerSuggestions(suggestions);
    
    const interval = setInterval(() => {
      if (step < getAnalysisText().length) {
        setAnalysisStep(step);
        step++;
      } else {
        clearInterval(interval);
      }
    }, 2000);
  };

  const handleCareerSelect = (career: string) => {
    setSelectedCareer(career);
    setStep('career-story');
    setCurrentStoryPart(0);
  };

  const handleStoryChoice = (choice: StoryChoice) => {
    if (choice.score) {
      const newScores = { ...scores };
      if (choice.score.analysis) newScores.analysis += choice.score.analysis;
      if (choice.score.communication) newScores.communication += choice.score.communication;
      setScores(newScores);
    }

    // Galatasaray forması seçildiğinde
    if (choice.text === "Galatasaray") {
      setIsGalatasarayFan(true);
    }

    // Update dimension based on choice
    if (choice.nextDimension) {
      if (choice.nextDimension === "failure") {
        setStep('failure');
        return;
      }
      setCurrentDimension(choice.nextDimension);
    }

    const storyParts = getStoryPartsForCareer();
    const nextPart = storyParts.findIndex(part => part.dimension === choice.nextDimension);
    
    if (nextPart !== -1) {
      setCurrentStoryPart(nextPart);
    } else if (currentStoryPart < storyParts.length - 1) {
      setCurrentStoryPart(currentStoryPart + 1);
    } else {
      setStep('success');
    }
  };

  const handleRestart = () => {
    setStep('intro');
    setCurrentQuestion(0);
    setScores({});
    setUserData({ name: '', age: 0 });
    setAnalysisStep(0);
    setCareerSuggestions([]);
    setSelectedCareer('');
    setCurrentStoryPart(0);
    setCurrentDimension('morning');
    setIsGalatasarayFan(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-xl p-8 max-w-3xl w-full">
        {step === 'intro' && <IntroSection onStart={() => setStep('name')} />}
        
        {(step === 'name' || step === 'age') && (
          <UserInfoForm
            userData={userData}
            onUpdateUserData={setUserData}
            onSubmit={() => setStep(step === 'name' ? 'age' : 'psychologist')}
            step={step}
          />
        )}

        {step === 'psychologist' && (
          <PsychologistStory
            userData={userData}
            onContinue={() => setStep('questions')}
          />
        )}

        {step === 'questions' && (
          <QuestionSection
            currentQuestion={currentQuestion}
            totalQuestions={questions.length}
            question={questions[currentQuestion]}
            onAnswerSelect={handleAnswerSelect}
          />
        )}

        {step === 'analysis' && (
          <AnalysisSection
            analysisText={getAnalysisText()}
            currentStep={analysisStep}
            careerSuggestions={careerSuggestions}
            onCareerSelect={handleCareerSelect}
          />
        )}

        {step === 'career-story' && (
          <StorySection
            storyPart={getStoryPartsForCareer().find(part => part.dimension === currentDimension) || getStoryPartsForCareer()[currentStoryPart]}
            onChoice={handleStoryChoice}
          />
        )}

        {(step === 'success' || step === 'failure') && (
          <ResultSection
            success={step === 'success'}
            onRestart={handleRestart}
          />
        )}
      </div>
    </div>
  );
}

export default App;